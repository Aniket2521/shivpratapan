import React, { useState } from 'react';
import { 
  FaHome, FaArrowRight, FaFileAlt, 
  FaShieldAlt, FaCheckCircle,
  FaPhoneAlt, FaMapMarkedAlt, FaDownload,
  FaHandHoldingUsd, FaCalendarAlt, FaLock,
  FaChevronRight, FaInfoCircle, FaUniversity,
  FaMobileAlt, FaRupeeSign
} from 'react-icons/fa';
import { useLanguage } from '../../contexts/LanguageContext';

const SavingAccount = () => {
  const { language, changeLanguage } = useLanguage();
  const [activeSection, setActiveSection] = useState('about');

  // Translations for Savings Account page
  const translations = {
    en: {
      // Navigation
      home: 'Home',
      account: 'Account',
      savingsAccount: 'Savings Account',
      openSavingsAccount: 'Open Savings Account',
      
      // Hero Section
      pageTitle: 'Savings Account',
      pageSubtitle: 'Secure your future with our trusted savings solutions. Enjoy attractive interest rates and complete banking freedom.',
      interestRate: 'Interest Rate',
      minBalance: 'Min Balance',
      freeServices: 'Free Services',
      
      // Features and Benefits
      features: 'Features & Benefits',
      security: 'Security',
      securityDesc: 'Your deposits are insured up to ₹5,00,000 by DICGC',
      attractiveRate: 'Attractive Interest Rate',
      attractiveRateDesc: 'Earn competitive interest rates on your savings',
      easyAccess: 'Easy Access',
      easyAccessDesc: 'Access your funds anytime through our branches and ATMs',
      minimumBalance: 'Low Minimum Balance',
      minimumBalanceDesc: 'Maintain just ₹1,000 as minimum balance',
      
      // Documents Required
      documentsRequired: 'Documents Required',
      documentsList: [
        'Passport size photographs (2)',
        'Aadhaar Card',
        'PAN Card',
        'Address Proof (Electricity Bill/Telephone Bill)',
        'Identity Proof (Voter ID/Driving License)'
      ],
      
      // How to Apply
      howToApply: 'How to Apply',
      applySteps: [
        'Visit your nearest branch',
        'Fill the account opening form',
        'Submit required documents',
        'Deposit initial amount',
        'Get your account number and passbook'
      ],
      
      // Contact Info
      needHelp: 'Need Help?',
      contactUs: 'Contact our customer service',
      callUs: 'Call us at',
      visitBranch: 'Visit your nearest branch'
    },
    mr: {
      // Navigation
      home: 'होम',
      account: 'खाते',
      savingsAccount: 'बचत खाते',
      openSavingsAccount: 'बचत खाते उघडा',
      
      // Hero Section
      pageTitle: 'बचत खाते',
      pageSubtitle: 'आमच्या विश्वसनीय बचत उपायांसह तुमभवती भविष्य सुरक्षित करा. आकर्षक व्याज दर आणि पूर्ण बँकिंग स्वातंत्र्याचा आनंद घ्या.',
      interestRate: 'व्याज दर',
      minBalance: 'किमान शिल्लक',
      freeServices: 'मोफ सेवा',
      
      // Features and Benefits
      features: 'वैशिष्ट्ये आणि फायदे',
      security: 'सुरक्षा',
      securityDesc: 'आपले ठेव DICGC द्वारे ₹5,00,000 पर्यंत विमा केले आहे',
      attractiveRate: 'आकर्षक व्याज दर',
      attractiveRateDesc: 'आपल्या बचतीवर स्पर्धात्मक व्याज दर मिळवा',
      easyAccess: 'सोपा प्रवेश',
      easyAccessDesc: 'आमच्या शाखा आणि ATM द्वारे कोणत्याही वेळी आपले निधी मिळवा',
      minimumBalance: 'कमी किमान शिल्लक',
      minimumBalanceDesc: 'किमान शिल्लक म्हणून फक्त ₹1,000 ठेवा',
      
      // Documents Required
      documentsRequired: 'आवश्यक कागदपत्रे',
      documentsList: [
        'पासपोर्ट आकाराचे फोटो (२)',
        'आधार कार्ड',
        'पॅन कार्ड',
        'पत्ता पुरावा (वीज बिल/टेलिफोन बिल)',
        'ओळख पुरावा (मतदार ओळखपत्र/ड्रायव्हिंग लायसन्स)'
      ],
      
      // How to Apply
      howToApply: 'अर्ज कसा करावा',
      applySteps: [
        'आपल्या जवळच्या शाखेला भेट द्या',
        'खाते उघडण्याचे फॉर्म भरा',
        'आवश्यक कागदपत्रे जमा करा',
        'प्रारंभिक रक्कम जमा करा',
        'आपले खाते क्रमांक आणि पासबुक मिळवा'
      ],
      
      // Contact Info
      needHelp: 'मदतीची आवश्यकता आहे का?',
      contactUs: 'आमच्या ग्राहक सेवेशी संपर्क साधा',
      callUs: 'आम्हाला कॉल करा',
      visitBranch: 'आपल्या जवळच्या शाखेला भेट द्या'
    }
  };

  const currentLang = language || 'en';
  const t = translations[currentLang] || translations.en;

  // Quick menu items
  const quickMenuItems = [
    { id: 'open', label: t.openSavingsAccount, icon: <FaFileAlt /> }
  ];


  // Handle scroll to section
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
    }
  };

  return (
    <div className="font-sans bg-gray-50">
      {/* 1. Hero Section with Breadcrumb */}
      <section 
        className="relative h-96 overflow-hidden"
        style={{
          background: 'linear-gradient(rgba(26, 35, 126, 0.85), rgba(26, 35, 126, 0.7)), url("https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1920")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0">
          {/* Decorative Pattern */}
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        <div className="relative h-full flex flex-col justify-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Breadcrumb */}
            <nav className="flex items-center text-white text-sm mb-6">
              <a href="/" className="flex items-center hover:text-blue-200 transition-colors">
                <FaHome className="mr-2" />
                {t.home}
              </a>
              <FaChevronRight className="mx-2 opacity-50" />
              <a href="/account" className="hover:text-blue-200 transition-colors">{t.account}</a>
              <FaChevronRight className="mx-2 opacity-50" />
              <span className="font-semibold">{t.savingsAccount}</span>
            </nav>

            {/* Page Heading */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
              {t.pageTitle}
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 max-w-3xl">
              {t.pageSubtitle}
            </p>

            {/* Quick Stats */}
            <div className="flex flex-wrap gap-6 mt-8">
              <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-xl px-6 py-3">
                <div className="text-white text-sm opacity-90">{t.interestRate}</div>
                <div className="text-2xl font-bold text-white">3.00% p.a.</div>
              </div>
              <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-xl px-6 py-3">
                <div className="text-white text-sm opacity-90">{t.minBalance}</div>
                <div className="text-2xl font-bold text-white">₹1,000</div>
              </div>
              <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-xl px-6 py-3">
                <div className="text-white text-sm opacity-90">{t.freeServices}</div>
                <div className="text-2xl font-bold text-white">25+</div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave Decoration */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="w-full h-12">
            <path d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" 
              opacity=".25" fill="white"></path>
            <path d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z" 
              opacity=".5" fill="white"></path>
            <path d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z" 
              fill="white"></path>
          </svg>
        </div>
      </section>

      {/* 2. Quick Navigation Menu */}
      <section className="sticky top-0 z-40 bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto py-4 space-x-1 scrollbar-hide">
            {quickMenuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`flex items-center px-5 py-3 rounded-lg whitespace-nowrap transition-all duration-300 ${
                  activeSection === item.id
                    ? 'bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span className="mr-2 text-lg">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* 3. About Savings Account */}
            <section id="about" className="scroll-mt-24">
              <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center mr-4">
                    <FaInfoCircle className="text-white text-xl" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-gray-800">About Our Savings Account</h2>
                    <p className="text-gray-600">Secure, flexible, and designed for your financial growth</p>
                  </div>
                </div>

                <div className="space-y-4 text-gray-700">
                  <p>
                    Our Savings Account is more than just a place to store your money - it's your financial partner 
                    in achieving your dreams. Designed with flexibility and security in mind, our account offers 
                    the perfect balance of growth potential and easy access to your funds.
                  </p>
                  <p>
                    Whether you're a salaried individual planning for the future, a student starting your 
                    financial journey, or a family building wealth together, our savings account is tailored 
                    to meet your unique needs.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                  <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                      <FaCheckCircle className="text-green-500 mr-2" />
                      Ideal For
                    </h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        Salaried Employees
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        Students & Youth
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        Senior Citizens
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        Families & Joint Accounts
                      </li>
                    </ul>
                  </div>

                  <div className="bg-green-50 rounded-xl p-6 border border-green-100">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                      <FaShieldAlt className="text-blue-500 mr-2" />
                      Key Benefits
                    </h4>
                    <ul className="space-y-2">
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                        RBI-insured up to ₹5 lakhs
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                        24/7 Digital Banking Access
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                        No Hidden Charges
                      </li>
                      <li className="flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                        Free Debit Card & Cheque Book
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-8">
            {/* Apply Now Card */}
            <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">Open Account Now</h3>
              <p className="text-blue-100 mb-6">Start your financial journey with us in just a few minutes</p>
              
              <div className="space-y-4">
                <button 
                  onClick={() => scrollToSection('open')}
                  className="w-full bg-white text-blue-700 py-3 rounded-lg font-bold text-lg hover:bg-blue-50 transition-colors"
                >
                  Apply Online
                </button>
                <button className="w-full bg-blue-700 text-white py-3 rounded-lg font-bold text-lg hover:bg-blue-600 transition-colors border border-blue-500">
                  <FaPhoneAlt className="inline mr-2" />
                  Call Branch
                </button>
                <button className="w-full bg-transparent text-white py-3 rounded-lg font-bold text-lg hover:bg-blue-700 transition-colors border border-white">
                  <FaDownload className="inline mr-2" />
                  Download Form
                </button>
              </div>

              <div className="mt-8 pt-6 border-t border-blue-500">
                <div className="flex items-center mb-4">
                  <FaCalendarAlt className="mr-3" />
                  <div>
                    <div className="font-semibold">Processing Time</div>
                    <div className="text-sm opacity-90">24-48 hours</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <FaLock className="mr-3" />
                  <div>
                    <div className="font-semibold">100% Secure</div>
                    <div className="text-sm opacity-90">Bank-grade encryption</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Quick Links</h3>
              <div className="space-y-3">
                <a href="#" className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <FaRupeeSign className="text-blue-600 mr-3" />
                  <span>Current Account</span>
                </a>
                <a href="#" className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <FaHandHoldingUsd className="text-green-600 mr-3" />
                  <span>Loan Products</span>
                </a>
                <a href="#" className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <FaUniversity className="text-purple-600 mr-3" />
                  <span>Fixed Deposits</span>
                </a>
                <a href="#" className="flex items-center p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <FaMobileAlt className="text-red-600 mr-3" />
                  <span>Mobile Banking</span>
                </a>
              </div>
            </div>

            {/* Contact Card */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl shadow-xl p-6 border border-green-100">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Need Help?</h3>
              <div className="space-y-4">
                <div className="flex items-center p-3 bg-white rounded-lg border border-green-200">
                  <FaPhoneAlt className="text-green-600 mr-3" />
                  <div>
                    <div className="font-medium text-gray-800">Customer Care</div>
                    <div className="text-green-700 font-bold">1800-123-4567</div>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-white rounded-lg border border-green-200">
                  <FaMapMarkedAlt className="text-green-600 mr-3" />
                  <div>
                    <div className="font-medium text-gray-800">Find Branch</div>
                    <div className="text-sm text-gray-600">Locate nearest branch</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 7. Call to Action Banner */}
        <section id="open" className="scroll-mt-24 mt-12">
          <div 
            className="rounded-2xl shadow-2xl overflow-hidden relative transform transition-all duration-500 hover:scale-[1.02]"
            style={{
              background: 'linear-gradient(135deg, #b03462 0%, #8a2c4d 50%, #6d233d 100%)',
              backgroundImage: 'radial-gradient(circle at 30% 40%, rgba(255,255,255,0.15) 0%, transparent 60%), linear-gradient(135deg, #b03462 0%, #8a2c4d 50%, #6d233d 100%)'
            }}
          >
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-64 h-64 opacity-20">
              <div className="absolute inset-0 rounded-full border-4 border-white transform rotate-45"></div>
            </div>
            <div className="absolute bottom-0 left-0 w-48 h-48 opacity-15">
              <div className="absolute inset-0 rounded-full border-4 border-white transform -rotate-12"></div>
            </div>
            
            <div className="p-16 text-center text-white relative z-10">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white bg-opacity-20 backdrop-blur-sm mb-4">
                  <FaHandHoldingUsd className="text-4xl" />
                </div>
              </div>
              
              <h2 className="text-5xl font-bold mb-6 leading-tight">
                Ready to Start Your
                <span className="block text-yellow-300">Financial Journey?</span>
              </h2>
              
              <p className="text-xl text-white text-opacity-90 mb-10 max-w-3xl mx-auto leading-relaxed">
                Join thousands of satisfied customers who trust Shivpratap Bank for their financial needs. 
                Open your savings account in minutes and enjoy exclusive benefits.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-6 justify-center mb-8">
                <button 
                  onClick={() => scrollToSection('open')}
                  className="bg-white text-[#b03462] px-10 py-5 rounded-full font-bold text-lg hover:bg-yellow-50 transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl border-2 border-transparent hover:border-yellow-300"
                >
                  <FaArrowRight className="inline mr-2" />
                  Apply Online Now
                </button>
                <button className="bg-transparent border-2 border-white text-white px-10 py-5 rounded-full font-bold text-lg hover:bg-white hover:text-[#b03462] transition-all duration-300 transform hover:-translate-y-2 hover:shadow-2xl">
                  <FaMapMarkedAlt className="inline mr-2" />
                  Visit Nearest Branch
                </button>
              </div>
              
              <div className="flex flex-wrap justify-center gap-8 text-white text-opacity-90">
                <div className="flex items-center">
                  <FaCheckCircle className="mr-2 text-green-300" />
                  <span>Zero paperwork</span>
                </div>
                <div className="flex items-center">
                  <FaCheckCircle className="mr-2 text-green-300" />
                  <span>Instant approval</span>
                </div>
                <div className="flex items-center">
                  <FaCheckCircle className="mr-2 text-green-300" />
                  <span>Dedicated support</span>
                </div>
                <div className="flex items-center">
                  <FaCheckCircle className="mr-2 text-green-300" />
                  <span>Free debit card</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Custom CSS */}
        <style jsx>{`
          .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
          }
          .scrollbar-hide::-webkit-scrollbar {
            display: none;
          }
          
          @keyframes fade-in-up {
            from {
              opacity: 0;
              transform: translateY(20px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
          
          .animate-fade-in-up {
            animation: fade-in-up 0.6s ease-out;
          }
        `}</style>
      </div>
    </div>
  );
};

export default SavingAccount;