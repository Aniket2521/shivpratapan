import React, { useState, useEffect } from 'react';
import { 
  FaCalculator, FaCoins, FaRupeeSign, FaCalendarAlt, 
  FaPercent, FaFileAlt, FaMapMarkerAlt, FaPhoneAlt,
  FaDownload, FaPrint, FaShareAlt, FaInfoCircle,
  FaQuestionCircle, FaHandHoldingUsd, FaShieldAlt,
  FaArrowRight, FaCheckCircle, FaClock, FaUserCheck,
  FaBuilding, FaMobileAlt, FaEnvelope, FaWhatsapp,
  FaChevronRight, FaSearch, FaFilter, FaChartLine
} from 'react-icons/fa';

const Calculator = () => {
  // Color constants
  const primaryColor = '#b03462';
  const secondaryColor = '#ffd166';
  const accentColor = '#06d6a0';
  const darkColor = '#1a1a2e';
  const lightColor = '#f8f9fa';

  // State management
  const [goldWeight, setGoldWeight] = useState(10);
  const [goldPurity, setGoldPurity] = useState('22K');
  const [goldRate, setGoldRate] = useState(5500);
  const [loanTenure, setLoanTenure] = useState(12);
  const [interestRate, setInterestRate] = useState(9.5);
  const [activeMenu, setActiveMenu] = useState('calculator');
  const [activeSubMenu, setActiveSubMenu] = useState('main');
  const [showResults, setShowResults] = useState(false);
  const [screenSize, setScreenSize] = useState('desktop');

  // Screen size detection
  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      if (width < 768) setScreenSize('mobile');
      else if (width < 1024) setScreenSize('tablet');
      else setScreenSize('desktop');
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Gold rate options
  const goldRates = {
    '22K': 5500,
    '24K': 6000
  };

  // Loan schemes
  const loanSchemes = [
    { name: "Quick Gold Loan", tenure: "3-12 months", rate: "9.5%", ltv: "75%" },
    { name: "Flexi Gold Loan", tenure: "12-24 months", rate: "10.5%", ltv: "70%" },
    { name: "Premium Gold Loan", tenure: "24-36 months", rate: "8.9%", ltv: "65%" },
    { name: "Instant Gold Loan", tenure: "1-6 months", rate: "12%", ltv: "80%" }
  ];

  // Calculate loan details
  const calculateLoan = () => {
    const purityMultiplier = goldPurity === '24K' ? 1 : 0.9167; // 22K purity
    const goldValue = goldWeight * goldRate * purityMultiplier;
    const eligibleAmount = goldValue * 0.75; // 75% LTV
    const monthlyInterestRate = interestRate / 12 / 100;
    const emi = eligibleAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, loanTenure) / 
                (Math.pow(1 + monthlyInterestRate, loanTenure) - 1);
    const totalInterest = (emi * loanTenure) - eligibleAmount;
    const totalAmount = emi * loanTenure;

    return {
      goldValue: goldValue.toFixed(2),
      eligibleAmount: eligibleAmount.toFixed(2),
      emi: emi.toFixed(2),
      totalInterest: totalInterest.toFixed(2),
      totalAmount: totalAmount.toFixed(2)
    };
  };

  const loanDetails = calculateLoan();

  // Menu options
  const mainMenu = [
    { id: 'calculator', icon: <FaCalculator />, label: 'Gold Loan Calculator' },
    { id: 'schemes', icon: <FaCoins />, label: 'Gold Loan Schemes' },
    { id: 'rates', icon: <FaRupeeSign />, label: 'Current Gold Rate' },
    { id: 'emi', icon: <FaCalendarAlt />, label: 'EMI Calculator' },
    { id: 'apply', icon: <FaHandHoldingUsd />, label: 'Apply for Gold Loan' },
    { id: 'documents', icon: <FaFileAlt />, label: 'Required Documents' },
    { id: 'interest', icon: <FaPercent />, label: 'Gold Loan Interest Rates' },
    { id: 'repayment', icon: <FaChartLine />, label: 'Repayment Options' },
    { id: 'branches', icon: <FaMapMarkerAlt />, label: 'Branch Locator' },
    { id: 'contact', icon: <FaPhoneAlt />, label: 'Contact Us' }
  ];

  const infoMenu = [
    { id: 'what-is', label: 'What is Gold Loan?' },
    { id: 'how-works', label: 'How Gold Loan Works' },
    { id: 'eligibility', label: 'Loan Eligibility' },
    { id: 'ltv', label: 'Loan to Value (LTV – 75%)' },
    { id: 'calculation', label: 'Interest Calculation' },
    { id: 'emi-vs-bullet', label: 'EMI vs Bullet Payment' },
    { id: 'prepayment', label: 'Prepayment Rules' },
    { id: 'safety', label: 'Safety of Gold' },
    { id: 'terms', label: 'Terms & Conditions' },
    { id: 'faqs', label: 'FAQs – Gold Loan' }
  ];

  const actionMenu = [
    { id: 'calculate', icon: <FaCalculator />, label: 'Calculate Now' },
    { id: 'apply-online', icon: <FaArrowRight />, label: 'Apply Online' },
    { id: 'visit-branch', icon: <FaBuilding />, label: 'Visit Nearest Branch' },
    { id: 'call-support', icon: <FaPhoneAlt />, label: 'Call Customer Care' },
    { id: 'download', icon: <FaDownload />, label: 'Download EMI Details' }
  ];

  // Today's gold rates
  const todaysRates = [
    { city: 'Mumbai', '22K': 5500, '24K': 6000, change: '+50' },
    { city: 'Delhi', '22K': 5450, '24K': 5950, change: '+45' },
    { city: 'Pune', '22K': 5480, '24K': 5980, change: '+40' },
    { city: 'Bangalore', '22K': 5520, '24K': 6020, change: '+55' }
  ];

  // Required documents
  const requiredDocuments = [
    'Identity Proof (Aadhar Card, PAN Card)',
    'Address Proof (Utility Bill, Passport)',
    'Recent Photographs (2 Passport Size)',
    'Gold Jewellery with Original Bills',
    'Income Proof (for higher amounts)',
    'KYC Documents'
  ];

  return (
    <div 
      className="font-sans min-h-screen relative overflow-hidden"
      style={{
        background: `linear-gradient(135deg, ${lightColor} 0%, white 100%)`
      }}
    >
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute top-0 right-0 w-96 h-96 rounded-full opacity-5"
          style={{ backgroundColor: primaryColor }}
        ></div>
        <div 
          className="absolute bottom-0 left-0 w-80 h-80 rounded-full opacity-5"
          style={{ backgroundColor: secondaryColor }}
        ></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 
            className="text-4xl md:text-5xl font-bold mb-4"
            style={{
              background: `linear-gradient(135deg, ${primaryColor} 0%, #d15679 100%)`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text'
            }}
          >
            Gold Loan Calculator
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Calculate your eligible loan amount instantly with our secure gold loan calculator
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Mobile Menu Bar */}
          <div className="lg:hidden w-full mb-6">
            <div 
              className="rounded-2xl shadow-xl p-4 border"
              style={{
                backgroundColor: 'white',
                borderColor: `${primaryColor}20`
              }}
            >
              <div className="flex items-center gap-3 mb-4">
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${primaryColor} 0%, #9c2956 100%)`
                  }}
                >
                  <FaCalculator className="text-lg text-white" />
                </div>
                <h3 className="font-bold" style={{ color: primaryColor }}>Gold Loan Menu</h3>
              </div>
              
              {/* Mobile Menu Grid */}
              <div className="grid grid-cols-2 gap-2">
                {mainMenu.slice(0, 6).map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveMenu(item.id)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-lg transition-all duration-300 ${
                      activeMenu === item.id ? 'shadow-md' : 'hover:bg-gray-50'
                    }`}
                    style={{
                      backgroundColor: activeMenu === item.id ? `${primaryColor}10` : 'transparent',
                      border: `2px solid ${activeMenu === item.id ? primaryColor : 'transparent'}`
                    }}
                  >
                    <div 
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{
                        backgroundColor: activeMenu === item.id ? primaryColor : `${primaryColor}15`,
                        color: activeMenu === item.id ? 'white' : primaryColor
                      }}
                    >
                      {item.icon}
                    </div>
                    <span className="text-xs font-medium text-center" style={{ color: activeMenu === item.id ? primaryColor : darkColor }}>
                      {item.label.length > 12 ? item.label.substring(0, 12) + '...' : item.label}
                    </span>
                  </button>
                ))}
              </div>
              
              {/* Mobile Action Buttons */}
              <div className="mt-4 grid grid-cols-2 gap-2">
                <button
                  onClick={() => setActiveMenu('calculator')}
                  className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg font-medium transition-all duration-300"
                  style={{
                    background: `linear-gradient(135deg, ${primaryColor} 0%, #d15679 100%)`,
                    color: 'white'
                  }}
                >
                  <FaCalculator className="text-sm" />
                  <span className="text-sm">Calculate</span>
                </button>
                <button
                  onClick={() => setActiveMenu('contact')}
                  className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg font-medium border transition-all duration-300"
                  style={{
                    borderColor: `${primaryColor}30`,
                    color: primaryColor
                  }}
                >
                  <FaPhoneAlt className="text-sm" />
                  <span className="text-sm">Contact</span>
                </button>
              </div>
            </div>
          </div>

          {/* Left Sidebar - Main Menu */}
          <div className="hidden lg:block lg:col-span-1">
            <div 
              className="rounded-2xl shadow-xl overflow-hidden border sticky top-8"
              style={{
                backgroundColor: 'white',
                borderColor: `${primaryColor}20`
              }}
            >
              {/* Menu Header */}
              <div 
                className="p-6 text-white"
                style={{
                  background: `linear-gradient(135deg, ${primaryColor} 0%, #9c2956 100%)`
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                    <FaCalculator className="text-2xl" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Gold Loan Menu</h3>
                    <p className="text-white/80 text-sm">All options in one place</p>
                  </div>
                </div>
              </div>

              {/* Main Menu */}
              <div className="p-4">
                <h4 className="font-bold mb-4 px-2" style={{ color: primaryColor }}>
                  🔹 Main Menu
                </h4>
                <div className="space-y-1">
                  {mainMenu.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setActiveMenu(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-300 ${
                        activeMenu === item.id
                          ? 'transform -translate-x-1 shadow-lg'
                          : 'hover:bg-gray-50'
                      }`}
                      style={{
                        backgroundColor: activeMenu === item.id ? `${primaryColor}10` : 'transparent',
                        border: `2px solid ${activeMenu === item.id ? primaryColor : 'transparent'}`
                      }}
                    >
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{
                          backgroundColor: activeMenu === item.id ? primaryColor : `${primaryColor}15`,
                          color: activeMenu === item.id ? 'white' : primaryColor
                        }}
                      >
                        {item.icon}
                      </div>
                      <span className="font-medium" style={{ color: activeMenu === item.id ? primaryColor : darkColor }}>
                        {item.label}
                      </span>
                      {activeMenu === item.id && (
                        <FaChevronRight className="ml-auto" style={{ color: primaryColor }} />
                      )}
                    </button>
                  ))}
                </div>

                {/* Information Menu */}
                <div className="mt-8">
                  <h4 className="font-bold mb-4 px-2" style={{ color: primaryColor }}>
                    📌 Gold Loan Information
                  </h4>
                  <div className="space-y-1">
                    {infoMenu.slice(0, 5).map((item) => (
                      <button
                        key={item.id}
                        className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-left hover:bg-gray-50 transition-colors duration-200"
                        style={{ color: darkColor }}
                      >
                        <FaInfoCircle style={{ color: `${primaryColor}60` }} />
                        <span className="text-sm">{item.label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Action Menu */}
                <div className="mt-8">
                  <h4 className="font-bold mb-4 px-2" style={{ color: primaryColor }}>
                    ⚙️ Quick Actions
                  </h4>
                  <div className="space-y-2">
                    {actionMenu.map((item) => (
                      <button
                        key={item.id}
                        className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-medium transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg ${
                          item.id === 'calculate' ? 'shadow-md' : ''
                        }`}
                        style={{
                          background: item.id === 'calculate' 
                            ? `linear-gradient(135deg, ${primaryColor} 0%, #d15679 100%)`
                            : `${primaryColor}10`,
                          color: item.id === 'calculate' ? 'white' : primaryColor,
                          border: `2px solid ${item.id === 'calculate' ? 'transparent' : `${primaryColor}20`}`
                        }}
                      >
                        {item.icon}
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className={`${screenSize === 'mobile' ? 'w-full' : 'lg:col-span-3'}`}>
            {/* Calculator Section */}
            {activeMenu === 'calculator' && (
              <div className="space-y-8">
                {/* Calculator Header */}
                <div 
                  className="rounded-2xl shadow-xl p-8 border"
                  style={{
                    backgroundColor: 'white',
                    borderColor: `${primaryColor}20`,
                    background: `linear-gradient(135deg, white 0%, ${lightColor} 100%)`
                  }}
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center"
                      style={{
                        background: `linear-gradient(135deg, ${secondaryColor} 0%, #ffc233 100%)`
                      }}
                    >
                      <FaCalculator className="text-2xl" style={{ color: darkColor }} />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold" style={{ color: darkColor }}>
                        Gold Loan Calculator
                      </h2>
                      <p className="text-gray-600">Calculate your loan eligibility in seconds</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Input Section */}
                    <div className="space-y-6">
                      <h3 className="font-bold text-lg" style={{ color: primaryColor }}>
                        🧾 Enter Your Details
                      </h3>
                      
                      {/* Gold Weight */}
                      <div>
                        <label className="block text-gray-700 mb-3 font-medium">
                          <FaCoins className="inline mr-2" style={{ color: primaryColor }} />
                          Gold Weight (in grams)
                        </label>
                        <div className="relative">
                          <input
                            type="range"
                            min="1"
                            max="1000"
                            value={goldWeight}
                            onChange={(e) => setGoldWeight(e.target.value)}
                            className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                            style={{
                              backgroundColor: `${primaryColor}30`,
                              backgroundImage: `linear-gradient(${primaryColor}, ${primaryColor})`,
                              backgroundSize: `${(goldWeight / 1000) * 100}% 100%`,
                              backgroundRepeat: 'no-repeat'
                            }}
                          />
                          <div className="flex justify-between mt-2">
                            <span className="text-sm text-gray-500">1g</span>
                            <span className="text-sm text-gray-500">1000g</span>
                          </div>
                          <div className="mt-4">
                            <div className="flex items-center gap-3">
                              <input
                                type="number"
                                value={goldWeight}
                                onChange={(e) => setGoldWeight(e.target.value)}
                                className="w-32 px-4 py-3 rounded-xl border text-center font-bold"
                                style={{
                                  borderColor: `${primaryColor}30`,
                                  backgroundColor: `${primaryColor}05`,
                                  color: primaryColor
                                }}
                              />
                              <span className="text-gray-600">grams</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Gold Purity */}
                      <div>
                        <label className="block text-gray-700 mb-3 font-medium">
                          <FaShieldAlt className="inline mr-2" style={{ color: primaryColor }} />
                          Gold Purity
                        </label>
                        <div className="grid grid-cols-2 gap-4">
                          {['22K', '24K'].map((purity) => (
                            <button
                              key={purity}
                              onClick={() => {
                                setGoldPurity(purity);
                                setGoldRate(goldRates[purity]);
                              }}
                              className={`px-6 py-4 rounded-xl border-2 font-bold transition-all duration-300 ${
                                goldPurity === purity
                                  ? 'transform -translate-y-1 shadow-lg'
                                  : 'hover:border-gray-300'
                              }`}
                              style={{
                                borderColor: goldPurity === purity ? primaryColor : '#e5e7eb',
                                backgroundColor: goldPurity === purity ? `${primaryColor}10` : 'white',
                                color: goldPurity === purity ? primaryColor : darkColor
                              }}
                            >
                              {purity} Gold
                              <div className="text-sm font-normal mt-1">
                                ₹{goldRates[purity].toLocaleString()}/g
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Gold Rate */}
                      <div>
                        <label className="block text-gray-700 mb-3 font-medium">
                          <FaRupeeSign className="inline mr-2" style={{ color: primaryColor }} />
                          Today's Gold Price (₹/gram)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            value={goldRate}
                            onChange={(e) => setGoldRate(e.target.value)}
                            className="w-full px-4 py-4 rounded-xl border pl-12 font-bold"
                            style={{
                              borderColor: `${primaryColor}30`,
                              backgroundColor: `${primaryColor}05`,
                              color: primaryColor
                            }}
                          />
                          <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
                            <FaRupeeSign style={{ color: `${primaryColor}60` }} />
                          </div>
                        </div>
                      </div>

                      {/* Loan Tenure */}
                      <div>
                        <label className="block text-gray-700 mb-3 font-medium">
                          <FaCalendarAlt className="inline mr-2" style={{ color: primaryColor }} />
                          Loan Tenure (months)
                        </label>
                        <div className="space-y-4">
                          <input
                            type="range"
                            min="3"
                            max="36"
                            step="3"
                            value={loanTenure}
                            onChange={(e) => setLoanTenure(e.target.value)}
                            className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                            style={{
                              backgroundColor: `${primaryColor}30`,
                              backgroundImage: `linear-gradient(${primaryColor}, ${primaryColor})`,
                              backgroundSize: `${((loanTenure - 3) / 33) * 100}% 100%`,
                              backgroundRepeat: 'no-repeat'
                            }}
                          />
                          <div className="flex flex-wrap gap-2">
                            {[3, 6, 12, 18, 24, 36].map((months) => (
                              <button
                                key={months}
                                onClick={() => setLoanTenure(months)}
                                className={`px-4 py-2 rounded-lg border ${
                                  loanTenure === months
                                    ? 'font-bold shadow-md'
                                    : 'hover:border-gray-300'
                                }`}
                                style={{
                                  borderColor: loanTenure === months ? primaryColor : '#e5e7eb',
                                  backgroundColor: loanTenure === months ? `${primaryColor}10` : 'white',
                                  color: loanTenure === months ? primaryColor : darkColor
                                }}
                              >
                                {months} months
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Interest Rate */}
                      <div>
                        <label className="block text-gray-700 mb-3 font-medium">
                          <FaPercent className="inline mr-2" style={{ color: primaryColor }} />
                          Interest Rate (% per annum)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.1"
                            value={interestRate}
                            onChange={(e) => setInterestRate(e.target.value)}
                            className="w-full px-4 py-4 rounded-xl border pr-12 font-bold"
                            style={{
                              borderColor: `${primaryColor}30`,
                              backgroundColor: `${primaryColor}05`,
                              color: primaryColor
                            }}
                          />
                          <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                            <FaPercent style={{ color: `${primaryColor}60` }} />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Results Section */}
                    <div className="space-y-6">
                      <h3 className="font-bold text-lg" style={{ color: primaryColor }}>
                        📊 Loan Calculation Results
                      </h3>
                      
                      <div className="space-y-4">
                        {/* Gold Value */}
                        <div 
                          className="p-6 rounded-2xl border"
                          style={{
                            borderColor: `${secondaryColor}30`,
                            backgroundColor: `${secondaryColor}10`
                          }}
                        >
                          <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center gap-3">
                              <div 
                                className="w-12 h-12 rounded-xl flex items-center justify-center"
                                style={{ backgroundColor: `${secondaryColor}30` }}
                              >
                                <FaCoins style={{ color: darkColor }} />
                              </div>
                              <div>
                                <div className="text-gray-600">Gold Value</div>
                                <div className="text-3xl font-bold" style={{ color: darkColor }}>
                                  ₹{parseFloat(loanDetails.goldValue).toLocaleString('en-IN')}
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="text-sm text-gray-600 mt-2">
                            Based on {goldWeight}g of {goldPurity} gold @ ₹{goldRate.toLocaleString()}/g
                          </div>
                        </div>

                        {/* Eligible Loan Amount */}
                        <div 
                          className="p-6 rounded-2xl border"
                          style={{
                            borderColor: `${primaryColor}30`,
                            backgroundColor: `${primaryColor}10`
                          }}
                        >
                          <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center gap-3">
                              <div 
                                className="w-12 h-12 rounded-xl flex items-center justify-center"
                                style={{ backgroundColor: `${primaryColor}30` }}
                              >
                                <FaHandHoldingUsd style={{ color: primaryColor }} />
                              </div>
                              <div>
                                <div className="text-gray-600">Eligible Loan Amount</div>
                                <div className="text-3xl font-bold" style={{ color: primaryColor }}>
                                  ₹{parseFloat(loanDetails.eligibleAmount).toLocaleString('en-IN')}
                                </div>
                              </div>
                            </div>
                            <div 
                              className="px-3 py-1 rounded-full text-sm font-bold"
                              style={{
                                backgroundColor: `${primaryColor}20`,
                                color: primaryColor
                              }}
                            >
                              75% LTV
                            </div>
                          </div>
                          <div className="text-sm text-gray-600 mt-2">
                            Maximum loan against 75% of gold value as per RBI guidelines
                          </div>
                        </div>

                        {/* EMI Details */}
                        <div 
                          className="p-6 rounded-2xl border"
                          style={{
                            borderColor: `${accentColor}30`,
                            backgroundColor: `${accentColor}10`
                          }}
                        >
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <div className="text-gray-600 mb-1">Monthly EMI</div>
                              <div className="text-2xl font-bold" style={{ color: accentColor }}>
                                ₹{parseFloat(loanDetails.emi).toLocaleString('en-IN')}
                              </div>
                            </div>
                            <div>
                              <div className="text-gray-600 mb-1">Tenure</div>
                              <div className="text-2xl font-bold" style={{ color: darkColor }}>
                                {loanTenure} months
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Total Amounts */}
                        <div className="grid grid-cols-2 gap-4">
                          <div 
                            className="p-4 rounded-xl border"
                            style={{
                              borderColor: `${primaryColor}20`,
                              backgroundColor: 'white'
                            }}
                          >
                            <div className="text-gray-600 text-sm mb-1">Total Interest</div>
                            <div className="text-xl font-bold" style={{ color: primaryColor }}>
                              ₹{parseFloat(loanDetails.totalInterest).toLocaleString('en-IN')}
                            </div>
                          </div>
                          <div 
                            className="p-4 rounded-xl border"
                            style={{
                              borderColor: `${darkColor}20`,
                              backgroundColor: 'white'
                            }}
                          >
                            <div className="text-gray-600 text-sm mb-1">Total Amount Payable</div>
                            <div className="text-xl font-bold" style={{ color: darkColor }}>
                              ₹{parseFloat(loanDetails.totalAmount).toLocaleString('en-IN')}
                            </div>
                          </div>
                        </div>

                        {/* Apply Now Button */}
                        <button
                          onClick={() => setShowResults(true)}
                          className="w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:-translate-y-1 hover:shadow-2xl active:scale-95"
                          style={{
                            background: `linear-gradient(135deg, ${primaryColor} 0%, #d15679 100%)`,
                            color: 'white'
                          }}
                        >
                          Apply Now for Gold Loan
                        </button>

                        {/* Action Buttons */}
                        <div className="grid grid-cols-3 gap-3">
                          <button 
                            className="py-3 rounded-lg border flex items-center justify-center gap-2 hover:shadow-md transition-all duration-300"
                            style={{
                              borderColor: `${primaryColor}30`,
                              backgroundColor: `${primaryColor}05`,
                              color: primaryColor
                            }}
                          >
                            <FaDownload />
                            <span className="text-sm">PDF</span>
                          </button>
                          <button 
                            className="py-3 rounded-lg border flex items-center justify-center gap-2 hover:shadow-md transition-all duration-300"
                            style={{
                              borderColor: `${primaryColor}30`,
                              backgroundColor: `${primaryColor}05`,
                              color: primaryColor
                            }}
                          >
                            <FaPrint />
                            <span className="text-sm">Print</span>
                          </button>
                          <button 
                            className="py-3 rounded-lg border flex items-center justify-center gap-2 hover:shadow-md transition-all duration-300"
                            style={{
                              borderColor: `${primaryColor}30`,
                              backgroundColor: `${primaryColor}05`,
                              color: primaryColor
                            }}
                          >
                            <FaShareAlt />
                            <span className="text-sm">Share</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Additional Information */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Today's Gold Rates */}
                  <div 
                    className="rounded-2xl shadow-xl p-6 border"
                    style={{
                      backgroundColor: 'white',
                      borderColor: `${primaryColor}20`
                    }}
                  >
                    <h3 className="font-bold mb-4 flex items-center gap-2" style={{ color: primaryColor }}>
                      <FaRupeeSign /> Today's Gold Rates
                    </h3>
                    <div className="space-y-3">
                      {todaysRates.map((rate, index) => (
                        <div 
                          key={index}
                          className="flex items-center justify-between p-3 rounded-lg border"
                          style={{ borderColor: `${primaryColor}10` }}
                        >
                          <div>
                            <div className="font-medium" style={{ color: darkColor }}>{rate.city}</div>
                            <div className="text-sm text-gray-600">22K: ₹{rate['22K']}</div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold" style={{ color: primaryColor }}>
                              ₹{rate['24K']}
                            </div>
                            <div className="text-sm" style={{ color: accentColor }}>
                              +{rate.change}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Quick Info */}
                  <div 
                    className="rounded-2xl shadow-xl p-6 border"
                    style={{
                      backgroundColor: 'white',
                      borderColor: `${primaryColor}20`
                    }}
                  >
                    <h3 className="font-bold mb-4 flex items-center gap-2" style={{ color: primaryColor }}>
                      <FaInfoCircle /> Quick Facts
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <FaShieldAlt className="mt-1" style={{ color: accentColor }} />
                        <div>
                          <div className="font-medium" style={{ color: darkColor }}>Gold Safety</div>
                          <div className="text-sm text-gray-600">Insured storage in RBI-approved vaults</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <FaClock className="mt-1" style={{ color: primaryColor }} />
                        <div>
                          <div className="font-medium" style={{ color: darkColor }}>Quick Disbursal</div>
                          <div className="text-sm text-gray-600">Amount credited within 30 minutes</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <FaUserCheck className="mt-1" style={{ color: secondaryColor }} />
                        <div>
                          <div className="font-medium" style={{ color: darkColor }}>Minimal Documentation</div>
                          <div className="text-sm text-gray-600">Only 2 documents required</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Required Documents */}
                  <div 
                    className="rounded-2xl shadow-xl p-6 border"
                    style={{
                      backgroundColor: 'white',
                      borderColor: `${primaryColor}20`
                    }}
                  >
                    <h3 className="font-bold mb-4 flex items-center gap-2" style={{ color: primaryColor }}>
                      <FaFileAlt /> Required Documents
                    </h3>
                    <div className="space-y-2">
                      {requiredDocuments.slice(0, 4).map((doc, index) => (
                        <div 
                          key={index}
                          className="flex items-center gap-3 p-3 rounded-lg border"
                          style={{ borderColor: `${primaryColor}10` }}
                        >
                          <FaCheckCircle style={{ color: accentColor }} />
                          <span className="text-sm" style={{ color: darkColor }}>{doc}</span>
                        </div>
                      ))}
                    </div>
                    <button className="w-full mt-4 py-2 rounded-lg border text-sm font-medium hover:shadow-sm transition-all duration-300"
                      style={{
                        borderColor: `${primaryColor}30`,
                        color: primaryColor
                      }}
                    >
                      View All Documents →
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Gold Loan Schemes */}
            {activeMenu === 'schemes' && (
              <div 
                className="rounded-2xl shadow-xl p-8 border"
                style={{
                  backgroundColor: 'white',
                  borderColor: `${primaryColor}20`
                }}
              >
                <h2 className="text-2xl font-bold mb-8" style={{ color: primaryColor }}>
                  Gold Loan Schemes
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {loanSchemes.map((scheme, index) => (
                    <div 
                      key={index}
                      className="p-6 rounded-2xl border transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl"
                      style={{
                        borderColor: `${primaryColor}20`,
                        backgroundColor: `${primaryColor}05`
                      }}
                    >
                      <div className="flex items-start justify-between mb-4">
                        <h3 className="text-xl font-bold" style={{ color: primaryColor }}>
                          {scheme.name}
                        </h3>
                        <div 
                          className="px-3 py-1 rounded-full text-sm font-bold"
                          style={{
                            backgroundColor: `${secondaryColor}30`,
                            color: darkColor
                          }}
                        >
                          {scheme.rate}
                        </div>
                      </div>
                      <div className="space-y-3 mb-6">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Tenure</span>
                          <span className="font-bold" style={{ color: darkColor }}>{scheme.tenure}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Loan to Value</span>
                          <span className="font-bold" style={{ color: primaryColor }}>{scheme.ltv}</span>
                        </div>
                      </div>
                      <button className="w-full py-3 rounded-lg font-medium transition-all duration-300 hover:shadow-md"
                        style={{
                          backgroundColor: `${primaryColor}10`,
                          color: primaryColor,
                          border: `2px solid ${primaryColor}20`
                        }}
                      >
                        View Details
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Contact Section */}
            {activeMenu === 'contact' && (
              <div 
                className="rounded-2xl shadow-xl p-8 border"
                style={{
                  backgroundColor: 'white',
                  borderColor: `${primaryColor}20`
                }}
              >
                <h2 className="text-2xl font-bold mb-8" style={{ color: primaryColor }}>
                  Contact Us
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 rounded-2xl border"
                    style={{ borderColor: `${primaryColor}20`, backgroundColor: `${primaryColor}05` }}>
                    <FaPhoneAlt className="text-3xl mx-auto mb-4" style={{ color: primaryColor }} />
                    <h3 className="font-bold mb-2" style={{ color: darkColor }}>Call Us</h3>
                    <div className="text-xl font-bold mb-2" style={{ color: primaryColor }}>1800-123-4567</div>
                    <p className="text-gray-600 text-sm">24/7 Customer Support</p>
                  </div>
                  <div className="text-center p-6 rounded-2xl border"
                    style={{ borderColor: `${primaryColor}20`, backgroundColor: `${primaryColor}05` }}>
                    <FaWhatsapp className="text-3xl mx-auto mb-4" style={{ color: '#25D366' }} />
                    <h3 className="font-bold mb-2" style={{ color: darkColor }}>WhatsApp</h3>
                    <div className="text-xl font-bold mb-2" style={{ color: primaryColor }}>+91 98765 43210</div>
                    <p className="text-gray-600 text-sm">Quick Query Resolution</p>
                  </div>
                  <div className="text-center p-6 rounded-2xl border"
                    style={{ borderColor: `${primaryColor}20`, backgroundColor: `${primaryColor}05` }}>
                    <FaEnvelope className="text-3xl mx-auto mb-4" style={{ color: primaryColor }} />
                    <h3 className="font-bold mb-2" style={{ color: darkColor }}>Email</h3>
                    <div className="text-xl font-bold mb-2" style={{ color: primaryColor }}>goldloan@bank.com</div>
                    <p className="text-gray-600 text-sm">Response within 2 hours</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Information Bar */}
        <div 
          className="mt-12 p-6 rounded-2xl border"
          style={{
            backgroundColor: `${primaryColor}08`,
            borderColor: `${primaryColor}20`
          }}
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <FaQuestionCircle className="text-2xl" style={{ color: primaryColor }} />
              <div>
                <div className="font-bold" style={{ color: darkColor }}>Need Help?</div>
                <div className="text-gray-600">Our gold loan experts are here to assist you</div>
              </div>
            </div>
            <div className="flex gap-3">
              <button className="px-6 py-3 rounded-xl font-medium border hover:shadow-md transition-all duration-300"
                style={{
                  borderColor: primaryColor,
                  color: primaryColor,
                  backgroundColor: 'white'
                }}
              >
                Chat Now
              </button>
              <button className="px-6 py-3 rounded-xl font-medium hover:shadow-md transition-all duration-300"
                style={{
                  backgroundColor: primaryColor,
                  color: 'white'
                }}
              >
                Book Appointment
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Custom CSS */}
      <style jsx>{`
        input[type="range"]::-webkit-slider-thumb {
          appearance: none;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: ${primaryColor};
          cursor: pointer;
          border: 3px solid white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        input[type="range"]::-moz-range-thumb {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: ${primaryColor};
          cursor: pointer;
          border: 3px solid white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }

        ::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb {
          background: ${primaryColor}60;
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: ${primaryColor}80;
        }

        /* Animation for results */
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fade-in-up {
          animation: fadeInUp 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default Calculator;