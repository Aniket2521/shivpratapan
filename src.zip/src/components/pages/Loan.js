import React, { useState, useEffect } from 'react';
import { 
  FaHome, FaChevronRight, FaCalculator, FaPercent, 
  FaCalendarAlt, FaHandHoldingUsd, FaUserCheck, 
  FaShieldAlt, FaRupeeSign, FaClock, FaHeart,
  FaGraduationCap, FaCar, FaBusinessTime, FaTractor,
  FaBuilding, FaArrowRight, FaPhoneAlt, FaMapMarkerAlt,
  FaDownload, FaFileAlt, FaTable, FaUsers, FaStar,
  FaCheckCircle, FaInfoCircle, FaBalanceScale, FaGem,
  FaPiggyBank, FaChartLine, FaUniversity, FaCogs,
  FaMobileAlt, FaWallet, FaLeaf, FaBook,
  FaIdCard, FaLandmark, FaFileContract, FaList,
  FaChevronLeft, FaChevronDown, FaSearch,
  FaRegFileAlt, FaRegChartBar, FaRegCreditCard,
  FaRegMoneyBillAlt, FaRegCalendarCheck
} from 'react-icons/fa';
import { GiReceiveMoney, GiPayMoney, GiMoneyStack, GiGoldBar, GiHouseKeys } from 'react-icons/gi';

const Loan = () => {
  const [activeLoan, setActiveLoan] = useState('personal-loan');
  const [showAllDocuments, setShowAllDocuments] = useState(false);
  const [expandedLoan, setExpandedLoan] = useState(null);

  // Loan navigation items
  const loanNavItems = [
    { id: 'personal-loan', label: 'Personal Loan', marathi: 'सामान्य कर्ज', icon: <FaHandHoldingUsd /> },
    { id: 'mortgage-loan', label: 'Mortgage Loan', marathi: 'तारण कर्ज', icon: <FaBuilding /> },
    { id: 'home-loan', label: 'Home Loan', marathi: 'गृह कर्ज', icon: <GiHouseKeys /> },
    { id: 'vehicle-loan', label: 'Vehicle Loan', marathi: 'वाहन कर्ज', icon: <FaCar /> },
    { id: 'gold-loan', label: 'Gold Loan', marathi: 'गोल्ड लोन', icon: <GiGoldBar /> },
    { id: 'women-loan', label: 'Women Loan', marathi: 'महिला कर्ज', icon: <FaHeart /> },
    { id: 'education-loan', label: 'Education Loan', marathi: 'शैक्षणिक कर्ज', icon: <FaGraduationCap /> }
  ];

  // Loan data with images - REPLACE WITH YOUR PROVIDED IMAGES
  const loanData = {
    'personal-loan': {
      title: 'Personal Loan',
      marathiTitle: 'सामान्य कर्ज',
      subtitle: 'For education, travel, medical expenses, marriage, etc.',
      marathiSubtitle: 'शिक्षण, प्रवास, वैद्यकीय खर्च, लग्न, इत्यादीसाठी',
      image: 'https://images.unsplash.com/photo-1579621970795-87facc2f976d?w=800&h=500&fit=crop',
      color: 'from-blue-600 to-indigo-700',
      icon: <FaHandHoldingUsd />,
      description: [
        'Unsecured loan for personal needs without collateral requirement',
        'Quick disbursal within 24-48 hours of approval',
        'Flexible end-use with no restrictions on usage',
        'Perfect for emergencies and planned expenses'
      ],
      eligibility: [
        { title: 'Citizenship', value: 'Indian citizen', icon: <FaIdCard /> },
        { title: 'Age Range', value: '21 to 60 years', icon: <FaUserCheck /> },
        { title: 'Minimum Income', value: '₹15,000/month (salaried)', icon: <FaRupeeSign /> },
        { title: 'Business Income', value: '₹45,000/month (self-employed)', icon: <FaBusinessTime /> }
      ],
      creditScore: {
        ideal: '750+',
        description: 'Good credit score helps in faster loan approval',
        levels: [
          { range: '300-599', label: 'Poor', color: 'bg-red-500' },
          { range: '600-699', label: 'Fair', color: 'bg-yellow-500' },
          { range: '700-749', label: 'Good', color: 'bg-green-500' },
          { range: '750-900', label: 'Excellent', color: 'bg-blue-500' }
        ]
      },
      loanAmount: 'Up to ₹1,00,000 (as per eligibility)',
      tenure: 'Up to 24 months',
      interestRate: '12% - 16%',
      benefits: [
        'No collateral required',
        'Quick processing time',
        'Minimal documentation',
        'Flexible repayment options',
        'Online application available'
      ],
      disadvantages: [
        'Higher interest rates',
        'Unsecured loan (no collateral)',
        'Strict eligibility criteria',
        'Processing fees applicable'
      ]
    },
    'mortgage-loan': {
      title: 'Mortgage Loan',
      marathiTitle: 'तारण कर्ज',
      subtitle: 'Lower interest loans against property',
      marathiSubtitle: 'मालमत्तेच्या तारणावर कमी व्याज दराचे कर्ज',
      image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=500&fit=crop',
      color: 'from-green-600 to-emerald-700',
      icon: <FaBuilding />,
      description: [
        'Secure loan against property with lower interest rates',
        'Loan amount up to 60-70% of property value',
        'Long repayment tenure available',
        'Suitable for business expansion, education, medical needs'
      ],
      features: [
        'Lower interest compared to other loans',
        'Long repayment tenure (up to 20 years)',
        'Higher loan amount available',
        'Flexible end-use options'
      ],
      types: [
        { name: 'Fixed Mortgage Loan', desc: 'Fixed interest rate for entire tenure' },
        { name: 'Adjustable Mortgage Loan', desc: 'Variable interest rate as per market' },
        { name: 'Simple Mortgage', desc: 'Basic mortgage without registration' },
        { name: 'Registered Mortgage', desc: 'Formally registered with authorities' },
        { name: 'Conditional Sale Mortgage', desc: 'Conditional property transfer' },
        { name: 'Usufructuary Mortgage', desc: 'Lender enjoys property benefits' }
      ],
      eligibility: [
        { title: 'Employment', value: 'Salaried or business person', icon: <FaUserCheck /> },
        { title: 'Age Limit', value: '18 to 65 years', icon: <FaCalendarAlt /> },
        { title: 'Property Ownership', value: 'Required', icon: <GiHouseKeys /> },
        { title: 'Income Proof', value: 'Required', icon: <FaRegMoneyBillAlt /> }
      ],
      documents: [
        'Aadhaar Card, PAN Card, Voter ID',
        'Original property documents',
        'Bank statements (last 6 months)',
        'Passport size photographs',
        'Income proof (salary slips/ITR)',
        'Property valuation report'
      ],
      interestRate: '12% - 14% (bank policy based)',
      loanAmount: 'Up to 70% of property value',
      tenure: 'Up to 20 years',
      benefits: [
        'Higher loan amount available',
        'Lower processing charges',
        'Faster approval for existing customers',
        'Tax benefits available'
      ]
    },
    'home-loan': {
      title: 'Home Loan',
      marathiTitle: 'गृह कर्ज',
      subtitle: 'Finance for your dream home',
      marathiSubtitle: 'तुमच्या स्वप्नांच्या घरासाठी वित्तपुरवठा',
      image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=800&h=500&fit=crop',
      color: 'from-purple-600 to-violet-700',
      icon: <GiHouseKeys />,
      purpose: [
        'Purchase house/flat',
        'Construct house',
        'Home extension/renovation',
        'Home improvement',
        'Balance transfer from other banks'
      ],
      eligibility: [
        { title: 'Citizenship', value: 'Indian citizen', icon: <FaIdCard /> },
        { title: 'Age Range', value: '18 to 70 years', icon: <FaUserCheck /> },
        { title: 'Credit Score', value: '750+ preferred', icon: <FaRegChartBar /> },
        { title: 'Minimum Income', value: '₹25,000/month', icon: <FaRupeeSign /> }
      ],
      documents: [
        'ID & address proof (Aadhaar, PAN, Voter ID)',
        'Salary slips (last 3 months) / ITR (2 years)',
        'Bank statements (last 6 months)',
        'Property documents (sale deed, agreement)',
        'Passport size photographs',
        'Occupation proof'
      ],
      interestRate: '8.4% - 9.5%',
      loanAmount: 'Up to ₹5,00,00,000',
      tenure: 'Up to 30 years',
      benefits: [
        'Low interest rates',
        'Long repayment tenure',
        'Tax benefits under Section 80C & 24',
        'Balance transfer facility',
        'Top-up loan available'
      ],
      specialFeatures: [
        'Women applicants get 0.25% lower interest',
        'Joint application with spouse/parents',
        'Online application and tracking',
        'Doorstep service available'
      ]
    },
    'vehicle-loan': {
      title: 'Vehicle Loan',
      marathiTitle: 'वाहन कर्ज',
      subtitle: 'Drive your dream vehicle',
      marathiSubtitle: 'तुमच्या स्वप्नांच्या वाहनासाठी कर्ज',
      image: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800&h=500&fit=crop',
      color: 'from-red-600 to-pink-700',
      icon: <FaCar />,
      features: [
        'Loan for two-wheeler and four-wheeler',
        'New and second-hand vehicles',
        'Flexible EMI options',
        'Quick processing within 24 hours',
        '100% on-road funding'
      ],
      eligibility: [
        { title: 'Age Limit', value: '18 to 65 years', icon: <FaUserCheck /> },
        { title: 'Income Source', value: 'Stable income required', icon: <FaRegMoneyBillAlt /> },
        { title: 'Driving License', value: 'Valid license required', icon: <FaIdCard /> },
        { title: 'Employment', value: 'Salaried or self-employed', icon: <FaBusinessTime /> }
      ],
      documents: [
        'Aadhaar Card, PAN Card',
        'Valid driving license',
        'Vehicle quotation/proforma invoice',
        'Salary slip/income proof (3 months)',
        'Bank statements (6 months)',
        'Passport size photographs',
        'Address proof'
      ],
      interestRate: '8.5% - 12%',
      loanAmount: 'Up to ₹50,00,000',
      tenure: '1-7 years',
      benefits: [
        'Quick processing & disbursement',
        'Flexible tenure options',
        'Insurance assistance',
        'Minimal documentation',
        'Online application facility'
      ],
      vehicleTypes: [
        { type: 'Two-wheeler', maxAmount: '₹5,00,000', tenure: '1-5 years' },
        { type: 'Four-wheeler (New)', maxAmount: '₹50,00,000', tenure: '1-7 years' },
        { type: 'Used Car', maxAmount: '₹25,00,000', tenure: '1-5 years' },
        { type: 'Commercial Vehicle', maxAmount: '₹1,00,00,000', tenure: '1-10 years' }
      ]
    },
    'gold-loan': {
      title: 'Gold Loan',
      marathiTitle: 'गोल्ड लोन',
      subtitle: 'Instant funds against your gold',
      marathiSubtitle: 'तुमच्या सोन्यावर त्वरित रक्कम',
      image: 'https://images.unsplash.com/photo-1580637250481-b78db3e6f84d?w=800&h=500&fit=crop',
      color: 'from-amber-500 to-yellow-600',
      icon: <GiGoldBar />,
      description: [
        'Quick loan against gold ornaments with minimal documentation',
        'Gold safe custody with insurance coverage',
        'Transparent gold valuation process',
        'Flexible repayment options'
      ],
      loanTypes: [
        {
          name: 'EMI Gold Loan',
          interest: '0.69% monthly',
          amount: 'Up to ₹75,000 per 10gm',
          tenure: '12 months',
          features: ['EMI + interest payment', 'Fixed monthly installments', 'Suitable for salaried']
        },
        {
          name: 'Easy Gold Loan',
          interest: '0.89% monthly',
          amount: 'Up to ₹75,000 per 10gm',
          tenure: '12 months',
          features: ['Monthly interest payment', 'Principal repayment at end', 'Flexible for business']
        },
        {
          name: 'Regular Gold Loan',
          interest: '0.83% monthly',
          amount: 'Up to ₹75,000 per 10gm',
          tenure: '12 months',
          features: ['Monthly interest payment', 'Gold release on full payment', 'Traditional option']
        }
      ],
      eligibility: [
        { title: 'Age Limit', value: '18 to 75 years', icon: <FaUserCheck /> },
        { title: 'Gold Purity', value: '18K or above', icon: <GiGoldBar /> },
        { title: 'Documentation', value: 'Minimal KYC', icon: <FaFileAlt /> },
        { title: 'Gold Ownership', value: 'Required', icon: <FaShieldAlt /> }
      ],
      benefits: [
        'Quick approval within 2 hours',
        'Minimal documentation required',
        'Safe gold storage with insurance',
        'No prepayment charges',
        'Transparent gold valuation'
      ],
      loanAmount: 'Up to 75% of gold value',
      tenure: '3 months to 3 years',
      process: [
        'Gold valuation by certified appraiser',
        'Loan sanction based on valuation',
        'Gold storage in secure vault',
        'Documentation and disbursement',
        'Gold return on full repayment'
      ]
    },
    'women-loan': {
      title: 'Women Loan',
      marathiTitle: 'महिला कर्ज',
      subtitle: 'Empowering women with financial independence',
      marathiSubtitle: 'आर्थिक स्वातंत्र्यासह महिलांना सशक्त बनवणे',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&h=500&fit=crop',
      color: 'from-pink-600 to-rose-700',
      icon: <FaHeart />,
      description: [
        'Special loan schemes designed exclusively for women',
        'Lower interest rates compared to standard loans',
        'Flexible repayment options tailored for women',
        'Quick approval process with minimal documentation'
      ],
      specialFeatures: [
        '0.25% lower interest rate for women',
        'Higher loan eligibility based on family income',
        'Flexible collateral requirements',
        'Special schemes for women entrepreneurs',
        'Priority processing for women applicants'
      ],
      eligibility: [
        { title: 'Gender', value: 'Women applicants only', icon: <FaUserCheck /> },
        { title: 'Age Range', value: '21 to 65 years', icon: <FaCalendarAlt /> },
        { title: 'Minimum Income', value: '₹12,000/month (salaried)', icon: <FaRupeeSign /> },
        { title: 'Business Income', value: '₹35,000/month (self-employed)', icon: <FaBusinessTime /> }
      ],
      documents: [
        'Aadhaar Card, PAN Card, Voter ID',
        'Bank statements (last 6 months)',
        'Income proof (salary slips/ITR)',
        'Passport size photographs',
        'Business registration (for entrepreneurs)',
        'Women identity proof (if applicable)'
      ],
      interestRate: '10% - 14%',
      loanAmount: 'Up to ₹10,00,000',
      tenure: 'Up to 36 months',
      benefits: [
        'Lower interest rates for women',
        'Higher loan eligibility',
        'Flexible repayment schedule',
        'Minimal documentation',
        'Priority processing',
        'Special schemes for women entrepreneurs'
      ],
      loanTypes: [
        { name: 'Women Business Loan', desc: 'For women entrepreneurs and business owners', maxAmount: '₹10,00,000' },
        { name: 'Women Personal Loan', desc: 'For personal needs and family requirements', maxAmount: '₹5,00,000' },
        { name: 'Women Education Loan', desc: 'For higher education and skill development', maxAmount: '₹15,00,000' },
        { name: 'Women Housing Loan', desc: 'For home purchase and renovation', maxAmount: '₹25,00,000' }
      ]
    },
    'education-loan': {
      title: 'Education Loan',
      marathiTitle: 'शैक्षणिक कर्ज',
      subtitle: 'Invest in your future education',
      marathiSubtitle: 'तुमच्या भविष्याच्या शिक्षणात गुंतवणे',
      image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&h=500&fit=crop',
      color: 'from-indigo-600 to-purple-700',
      icon: <FaGraduationCap />,
      description: [
        'Comprehensive education funding for students',
        'Coverage for tuition fees, books, and living expenses',
        'Moratorium period during study duration',
        'Tax benefits under Section 80E'
      ],
      features: [
        'Loan for studies in India and abroad',
        'Coverage for all education-related expenses',
        'Simple interest during study period',
        'Long repayment tenure after course completion',
        'Tax benefits on interest paid'
      ],
      eligibility: [
        { title: 'Citizenship', value: 'Indian citizen', icon: <FaIdCard /> },
        { title: 'Age Limit', value: '16 to 35 years', icon: <FaUserCheck /> },
        { title: 'Academic Record', value: 'Good academic performance', icon: <FaUniversity /> },
        { title: 'Admission Confirmed', value: 'Required', icon: <FaFileContract /> }
      ],
      documents: [
        'Aadhaar Card, PAN Card',
        'Academic certificates and mark sheets',
        'Admission confirmation letter',
        'Fee structure from institution',
        'Parents/guardian income proof',
        'Bank statements (last 6 months)',
        'Passport size photographs'
      ],
      interestRate: '8% - 11%',
      loanAmount: 'Up to ₹50,00,000',
      tenure: 'Up to 15 years',
      benefits: [
        'Lower interest rates compared to other loans',
        'Tax benefits under Section 80E',
        'Moratorium during study period',
        'Flexible repayment options',
        'Coverage for all education expenses',
        'No collateral required up to certain limit'
      ],
      coveredExpenses: [
        'Tuition and college fees',
        'Examination and library fees',
        'Books and equipment costs',
        'Travel expenses for studies abroad',
        'Hostel and accommodation charges',
        'Laptop and study materials'
      ],
      loanCategories: [
        { category: 'Undergraduate Studies', maxAmount: '₹20,00,000', tenure: '10 years' },
        { category: 'Postgraduate Studies', maxAmount: '₹30,00,000', tenure: '12 years' },
        { category: 'Professional Courses', maxAmount: '₹25,00,000', tenure: '10 years' },
        { category: 'Studies Abroad', maxAmount: '₹50,00,000', tenure: '15 years' }
      ]
    }
  };

  // Common documents for all loans
  const commonDocuments = [
    { name: 'Aadhaar Card', icon: <FaIdCard />, mandatory: true },
    { name: 'PAN Card', icon: <FaRegCreditCard />, mandatory: true },
    { name: 'Address Proof', icon: <FaMapMarkerAlt />, mandatory: true },
    { name: 'Passport Size Photo', icon: <FaUserCheck />, mandatory: true },
    { name: 'Bank Statements (6 months)', icon: <FaRegFileAlt />, mandatory: true },
    { name: 'Income Proof', icon: <FaRegMoneyBillAlt />, mandatory: true },
    { name: 'Property Documents', icon: <FaLandmark />, mandatory: false },
    { name: 'Vehicle Documents', icon: <FaCar />, mandatory: false },
    { name: 'Employment Proof', icon: <FaBusinessTime />, mandatory: false },
    { name: 'Business Proof', icon: <FaRegChartBar />, mandatory: false }
  ];

  // Handle scroll to loan section
  const scrollToLoan = (loanId) => {
    const element = document.getElementById(loanId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveLoan(loanId);
    }
  };

  // Handle hash-based navigation
  useEffect(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash && loanData[hash]) {
      setTimeout(() => scrollToLoan(hash), 100);
    }
  }, []);

  // Toggle loan expansion
  const toggleLoanExpansion = (loanId) => {
    if (expandedLoan === loanId) {
      setExpandedLoan(null);
    } else {
      setExpandedLoan(loanId);
      scrollToLoan(loanId);
    }
  };

  const currentLoan = loanData[activeLoan];

  return (
    <div className="font-sans bg-gradient-to-b from-gray-50 to-white min-h-screen">
      {/* 1. Hero Banner Section */}
      <section className="relative h-[500px] overflow-hidden bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1920")'
          }}
        />
        
        <div className="relative h-full flex flex-col justify-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Breadcrumb */}
            <nav className="flex items-center text-blue-100 text-sm mb-8">
              <a href="/" className="flex items-center hover:text-white transition-colors">
                <FaHome className="mr-2" />
                Home
              </a>
              <FaChevronRight className="mx-2 opacity-50" />
              <span className="font-semibold text-white">Loans</span>
            </nav>

            {/* Main Heading */}
            <div className="mb-10">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6">
                Loan <span className="bg-gradient-to-r from-cyan-300 to-blue-200 bg-clip-text text-transparent">Products</span>
              </h1>
              
              <p className="text-2xl md:text-3xl text-blue-100 max-w-3xl mb-8">
                Financial support for every personal and business need
              </p>
            </div>

            {/* Loan Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-blue-300/30">
                <div className="text-3xl font-bold text-white">5+</div>
                <div className="text-blue-200">Loan Types</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-blue-300/30">
                <div className="text-3xl font-bold text-white">8.5%</div>
                <div className="text-blue-200">Lowest Interest</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-blue-300/30">
                <div className="text-3xl font-bold text-white">₹5 Cr</div>
                <div className="text-blue-200">Max Loan</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-blue-300/30">
                <div className="text-3xl font-bold text-white">30 Years</div>
                <div className="text-blue-200">Max Tenure</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Sticky Loan Navigation */}
      <div className="sticky top-0 z-50 bg-white shadow-lg border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto py-4 space-x-4 scrollbar-hide">
            {loanNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToLoan(item.id)}
                className={`flex items-center px-6 py-3 rounded-xl whitespace-nowrap transition-all duration-300 ${
                  activeLoan === item.id
                    ? `bg-gradient-to-r ${loanData[item.id]?.color || 'from-blue-600 to-indigo-700'} text-white shadow-lg transform -translate-y-1`
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span className="mr-3 text-xl">{item.icon}</span>
                <div className="text-left">
                  <div className="font-medium">{item.label}</div>
                  <div className="text-xs opacity-90">{item.marathi}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content - Loan Details */}
          <div className="lg:col-span-3">
            {/* Loan Sections */}
            {loanNavItems.map((navItem) => (
              <section 
                key={navItem.id} 
                id={navItem.id} 
                className={`scroll-mt-28 mb-16 ${expandedLoan && expandedLoan !== navItem.id ? 'hidden lg:block' : ''}`}
              >
                <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200">
                  {/* Loan Header */}
                  <div className={`bg-gradient-to-r ${loanData[navItem.id].color} p-8 text-white`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center mb-2">
                          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center mr-4">
                            <span className="text-2xl">{loanData[navItem.id].icon}</span>
                          </div>
                          <div>
                            <h2 className="text-3xl font-bold">{loanData[navItem.id].title}</h2>
                            <p className="text-blue-100">{loanData[navItem.id].marathiTitle}</p>
                          </div>
                        </div>
                        <p className="mt-2 opacity-90">{loanData[navItem.id].subtitle}</p>
                        <p className="text-sm opacity-80">{loanData[navItem.id].marathiSubtitle}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold">{loanData[navItem.id].interestRate}</div>
                        <div className="text-sm opacity-90">Interest Rate</div>
                      </div>
                    </div>
                  </div>

                  {/* Loan Image and Content */}
                  <div className="p-8">
                    {/* Loan Image */}
                    <div className="mb-8 rounded-xl overflow-hidden shadow-lg">
                      <img 
                        src={loanData[navItem.id].image} 
                        alt={loanData[navItem.id].title}
                        className="w-full h-64 object-cover"
                      />
                    </div>

                    {/* Two Column Layout */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                      {/* Left Column */}
                      <div>
                        {/* Description */}
                        {loanData[navItem.id].description && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaInfoCircle className="text-blue-600 mr-3" />
                              Description
                            </h3>
                            <ul className="space-y-3">
                              {loanData[navItem.id].description.map((desc, idx) => (
                                <li key={idx} className="flex items-start">
                                  <FaCheckCircle className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                                  <span className="text-gray-700">{desc}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* Specific Features per Loan Type */}
                        {navItem.id === 'mortgage-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaList className="text-green-600 mr-3" />
                              Types of Mortgage Loans
                            </h3>
                            <div className="space-y-3">
                              {loanData[navItem.id].types.map((type, idx) => (
                                <div key={idx} className="bg-gray-50 p-4 rounded-lg">
                                  <div className="font-semibold text-gray-800">{type.name}</div>
                                  <div className="text-sm text-gray-600 mt-1">{type.desc}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {navItem.id === 'gold-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <GiGoldBar className="text-amber-600 mr-3" />
                              Gold Loan Types
                            </h3>
                            <div className="space-y-4">
                              {loanData[navItem.id].loanTypes.map((type, idx) => (
                                <div key={idx} className="border border-amber-200 rounded-xl p-4 bg-amber-50">
                                  <div className="font-bold text-gray-800 mb-2">{type.name}</div>
                                  <div className="grid grid-cols-2 gap-2 text-sm">
                                    <div>
                                      <span className="font-medium">Interest:</span> {type.interest}
                                    </div>
                                    <div>
                                      <span className="font-medium">Amount:</span> {type.amount}
                                    </div>
                                    <div>
                                      <span className="font-medium">Tenure:</span> {type.tenure}
                                    </div>
                                  </div>
                                  <div className="mt-3">
                                    <div className="text-sm font-medium mb-1">Features:</div>
                                    <ul className="text-sm text-gray-600 space-y-1">
                                      {type.features.map((feature, fIdx) => (
                                        <li key={fIdx} className="flex items-start">
                                          <FaCheckCircle className="text-green-500 text-xs mt-1 mr-2 flex-shrink-0" />
                                          {feature}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {navItem.id === 'vehicle-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaCar className="text-red-600 mr-3" />
                              Vehicle Types
                            </h3>
                            <div className="grid grid-cols-2 gap-4">
                              {loanData[navItem.id].vehicleTypes.map((vehicle, idx) => (
                                <div key={idx} className="bg-gray-50 p-4 rounded-lg">
                                  <div className="font-semibold text-gray-800">{vehicle.type}</div>
                                  <div className="text-sm text-gray-600">Max: {vehicle.maxAmount}</div>
                                  <div className="text-sm text-gray-600">Tenure: {vehicle.tenure}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {navItem.id === 'home-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <GiHouseKeys className="text-purple-600 mr-3" />
                              Purpose
                            </h3>
                            <div className="space-y-2">
                              {loanData[navItem.id].purpose.map((purpose, idx) => (
                                <div key={idx} className="flex items-center">
                                  <FaCheckCircle className="text-green-500 mr-3 flex-shrink-0" />
                                  <span className="text-gray-700">{purpose}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {navItem.id === 'women-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaHeart className="text-pink-600 mr-3" />
                              Special Features for Women
                            </h3>
                            <div className="space-y-2">
                              {loanData[navItem.id].specialFeatures.map((feature, idx) => (
                                <div key={idx} className="flex items-center">
                                  <FaCheckCircle className="text-green-500 mr-3 flex-shrink-0" />
                                  <span className="text-gray-700">{feature}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {navItem.id === 'education-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaGraduationCap className="text-indigo-600 mr-3" />
                              Covered Expenses
                            </h3>
                            <div className="space-y-2">
                              {loanData[navItem.id].coveredExpenses.map((expense, idx) => (
                                <div key={idx} className="flex items-center">
                                  <FaCheckCircle className="text-green-500 mr-3 flex-shrink-0" />
                                  <span className="text-gray-700">{expense}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Right Column */}
                      <div>
                        {/* Eligibility */}
                        <div className="mb-8">
                          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                            <FaUserCheck className="text-blue-600 mr-3" />
                            Eligibility
                          </h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {loanData[navItem.id].eligibility.map((item, idx) => (
                              <div key={idx} className="bg-blue-50 p-4 rounded-lg">
                                <div className="flex items-center mb-2">
                                  <div className="text-blue-600 mr-2">
                                    {item.icon}
                                  </div>
                                  <div className="text-sm font-medium text-gray-600">{item.title}</div>
                                </div>
                                <div className="font-semibold text-gray-800">{item.value}</div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Credit Score Info for Personal Loan */}
                        {navItem.id === 'personal-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaChartLine className="text-green-600 mr-3" />
                              Credit Score Information
                            </h3>
                            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl border border-green-200">
                              <div className="text-center mb-6">
                                <div className="text-3xl font-bold text-green-700">{loanData[navItem.id].creditScore.ideal}</div>
                                <div className="text-green-600 font-medium">Ideal Credit Score</div>
                                <p className="text-gray-600 mt-2">{loanData[navItem.id].creditScore.description}</p>
                              </div>
                              <div className="grid grid-cols-4 gap-2">
                                {loanData[navItem.id].creditScore.levels.map((level, idx) => (
                                  <div key={idx} className="text-center">
                                    <div className={`h-2 w-full rounded-full ${level.color} mb-2`}></div>
                                    <div className="text-xs font-medium">{level.range}</div>
                                    <div className="text-xs text-gray-600">{level.label}</div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Loan Details */}
                        <div className="mb-8">
                          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                            <FaRupeeSign className="text-green-600 mr-3" />
                            Loan Details
                          </h3>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <div className="text-sm text-gray-600 mb-1">Loan Amount</div>
                              <div className="text-lg font-bold text-gray-800">{loanData[navItem.id].loanAmount}</div>
                            </div>
                            <div className="bg-gray-50 p-4 rounded-lg">
                              <div className="text-sm text-gray-600 mb-1">Max Tenure</div>
                              <div className="text-lg font-bold text-gray-800">{loanData[navItem.id].tenure}</div>
                            </div>
                          </div>
                        </div>

                        {/* Benefits */}
                        <div className="mb-8">
                          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                            <FaStar className="text-amber-500 mr-3" />
                            Benefits
                          </h3>
                          <div className="space-y-2">
                            {loanData[navItem.id].benefits.map((benefit, idx) => (
                              <div key={idx} className="flex items-center">
                                <FaCheckCircle className="text-green-500 mr-3 flex-shrink-0" />
                                <span className="text-gray-700">{benefit}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Loan Types for Women Loan */}
                        {navItem.id === 'women-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaList className="text-pink-600 mr-3" />
                              Women Loan Types
                            </h3>
                            <div className="space-y-3">
                              {loanData[navItem.id].loanTypes.map((type, idx) => (
                                <div key={idx} className="bg-pink-50 p-4 rounded-lg border border-pink-200">
                                  <div className="font-semibold text-gray-800">{type.name}</div>
                                  <div className="text-sm text-gray-600 mt-1">{type.desc}</div>
                                  <div className="text-sm text-pink-600 font-medium mt-2">Max Amount: {type.maxAmount}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Loan Categories for Education Loan */}
                        {navItem.id === 'education-loan' && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaUniversity className="text-indigo-600 mr-3" />
                              Education Loan Categories
                            </h3>
                            <div className="grid grid-cols-2 gap-4">
                              {loanData[navItem.id].loanCategories.map((category, idx) => (
                                <div key={idx} className="bg-indigo-50 p-4 rounded-lg">
                                  <div className="font-semibold text-gray-800">{category.category}</div>
                                  <div className="text-sm text-gray-600">Max: {category.maxAmount}</div>
                                  <div className="text-sm text-gray-600">Tenure: {category.tenure}</div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Disadvantages for Personal Loan */}
                        {navItem.id === 'personal-loan' && loanData[navItem.id].disadvantages && (
                          <div className="mb-8">
                            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                              <FaInfoCircle className="text-red-600 mr-3" />
                              Things to Consider
                            </h3>
                            <div className="space-y-2">
                              {loanData[navItem.id].disadvantages.map((disadv, idx) => (
                                <div key={idx} className="flex items-center">
                                  <FaInfoCircle className="text-red-500 mr-3 flex-shrink-0" />
                                  <span className="text-gray-700">{disadv}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            ))}

            {/* 8. Common Documents Section */}
            <section className="scroll-mt-28 mb-16">
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl shadow-2xl p-8 border border-gray-700">
                <div className="text-center mb-10">
                  <h2 className="text-3xl font-bold text-white mb-4">Common Loan Documents</h2>
                  <p className="text-gray-400">Documents required for all loan applications</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-8">
                  {commonDocuments.slice(0, showAllDocuments ? commonDocuments.length : 5).map((doc, idx) => (
                    <div 
                      key={idx} 
                      className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-xl p-6 border border-gray-700 hover:border-blue-500 transition-all duration-300 group"
                    >
                      <div className="flex flex-col items-center text-center">
                        <div className={`w-14 h-14 rounded-xl ${
                          doc.mandatory 
                            ? 'bg-gradient-to-r from-red-500 to-pink-600' 
                            : 'bg-gradient-to-r from-blue-500 to-cyan-600'
                        } flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                          <div className="text-white text-2xl">
                            {doc.icon}
                          </div>
                        </div>
                        <h3 className="font-bold text-white text-lg mb-2">{doc.name}</h3>
                        <span className={`text-xs px-3 py-1 rounded-full ${
                          doc.mandatory 
                            ? 'bg-red-500/20 text-red-300' 
                            : 'bg-blue-500/20 text-blue-300'
                        }`}>
                          {doc.mandatory ? 'Mandatory' : 'As Required'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-center">
                  <button
                    onClick={() => setShowAllDocuments(!showAllDocuments)}
                    className="text-blue-400 hover:text-blue-300 font-medium flex items-center justify-center mx-auto"
                  >
                    {showAllDocuments ? 'Show Less Documents' : 'Show All Documents'}
                    <FaChevronDown className={`ml-2 transition-transform ${showAllDocuments ? 'rotate-180' : ''}`} />
                  </button>
                </div>
              </div>
            </section>
          </div>
      </div>

        {/* 9. Call-to-Action Section */}
        <section className="mt-16">
          <div className="relative overflow-hidden rounded-2xl shadow-2xl bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
              }}></div>
            </div>

            <div className="relative p-12 text-center text-white z-10">
              <div className="max-w-4xl mx-auto">
                <h2 className="text-4xl md:text-5xl font-bold mb-6">
                  Apply for the Right <span className="bg-gradient-to-r from-cyan-300 to-white bg-clip-text text-transparent">Loan Today</span>
                </h2>
                <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">
                  Get personalized loan solutions with minimal documentation and quick approval
                </p>
                
                <div className="flex flex-col sm:flex-row gap-6 justify-center">
                  <button className="bg-white text-blue-700 px-10 py-5 rounded-full font-bold text-xl hover:bg-blue-50 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 shadow-lg">
                    Apply Now
                  </button>
                  <button className="bg-transparent border-2 border-white text-white px-10 py-5 rounded-full font-bold text-xl hover:bg-white hover:bg-opacity-10 transition-all duration-300 shadow-lg">
                    <FaPhoneAlt className="inline mr-2" />
                    Visit Nearest Branch
                  </button>
                </div>
                
                <div className="mt-10 pt-8 border-t border-blue-300">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-cyan-300">24 Hrs</div>
                      <div className="text-blue-200">Approval Time</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-cyan-300">100%</div>
                      <div className="text-blue-200">Transparent</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-cyan-300">₹5 Cr</div>
                      <div className="text-blue-200">Max Loan</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-cyan-300">0.5%</div>
                      <div className="text-blue-200">Processing Fee</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Custom Styles */}
      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in {
          animation: fadeIn 0.5s ease-out;
        }
        
        /* Smooth scrolling */
        html {
          scroll-behavior: smooth;
        }
        
        /* Custom hover effects */
        .loan-card-hover {
          transition: all 0.3s ease;
        }
        
        .loan-card-hover:hover {
          transform: translateY(-4px);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        
        /* Gradient text animation */
        .gradient-text {
          background: linear-gradient(45deg, #06b6d4, #3b82f6, #8b5cf6);
          background-size: 200% 200%;
          animation: gradient 3s ease infinite;
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        
        @keyframes gradient {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        
        /* Custom bullet points */
        .custom-bullet {
          position: relative;
          padding-left: 1.5rem;
        }
        
        .custom-bullet::before {
          content: '';
          position: absolute;
          left: 0;
          top: 0.7rem;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: linear-gradient(45deg, #3b82f6, #06b6d4);
        }
      `}</style>
    </div>
  );
};

export default Loan;
