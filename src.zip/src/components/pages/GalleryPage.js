import React, { useState, useEffect } from 'react';
import { 
  FaHome, FaChevronRight, FaCamera, FaCalendarAlt, 
  FaBuilding, FaUsers, FaNewspaper, FaImages,
  FaTimes, FaChevronLeft, FaChevronRight as FaChevronRightIcon,
  FaStar, FaHeart, FaDownload, FaShareAlt, FaExpand,
  FaMapMarkerAlt, FaEye, FaPlayCircle, FaGlobe, FaCaretDown
} from 'react-icons/fa';
import { GiPartyPopper, GiTrophy } from 'react-icons/gi';
import { 
  database, 
  ref as dbRef, 
  get 
} from '../../firebase';
import { useLanguage } from '../../contexts/LanguageContext';

const GalleryPage = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedImage, setSelectedImage] = useState(null);
  const [showLightbox, setShowLightbox] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [galleryImages, setGalleryImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const { language, changeLanguage } = useLanguage();
  const [selectedLanguage, setSelectedLanguage] = useState('English');

  // Sync selectedLanguage with context language
  useEffect(() => {
    setSelectedLanguage(language === 'en' ? 'English' : 'मराठी');
  }, [language]);

  // Language options
  const languages = [
    { code: 'en', name: 'English' },
    { code: 'mr', name: 'मराठी' }
  ];

  // Translations for Gallery content
  const translations = {
    en: {
      title: 'Our',
      titleHighlight: 'Gallery',
      subtitle: 'Capturing moments of trust, growth, and celebration',
      breadcrumbHome: 'Home',
      breadcrumbGallery: 'Gallery',
      categories: {
        all: 'All'
      },
      allPhotos: 'All Photos',
      photos: 'Photos',
      image: 'image',
      images: 'images',
      noImagesFound: 'No images found',
      tryDifferentCategory: 'Try selecting a different category'
    },
    mr: {
      title: 'आमची',
      titleHighlight: 'गॅलरी',
      subtitle: 'विश्वास, वाढ आणि उत्सवाचे क्षण मोजत आहे',
      breadcrumbHome: 'होम',
      breadcrumbGallery: 'गॅलरी',
      categories: {
        all: 'सर्व'
      },
      allPhotos: 'सर्व फोटो',
      photos: 'फोटो',
      image: 'प्रतिमा',
      images: 'प्रतिमा',
      noImagesFound: 'कोणतेही चित्र सापडले नाहीत',
      tryDifferentCategory: 'वेगळी श्रेणी निवडण्याचा प्रयत्न करा'
    }
  };

  // Get current language content
  const currentLang = language;
  const currentContent = translations[currentLang];

  // Handle language change
  const handleLanguageChange = (lang) => {
    setSelectedLanguage(lang);
    const langCode = lang === 'English' ? 'en' : 'mr';
    changeLanguage(langCode);
  };

  // Load images from Firebase
  useEffect(() => {
    loadGalleryImages();
  }, []);

  const loadGalleryImages = async () => {
    try {
      setLoading(true);
      const galleryRef = dbRef(database, 'shivpratapmultistate/gallery');
      const snapshot = await get(galleryRef);
      
      if (snapshot.exists()) {
        const galleryData = snapshot.val();
        const imagesList = Object.keys(galleryData).map(key => ({
          id: key,
          ...galleryData[key]
        }));
        setGalleryImages(imagesList);
      }
    } catch (error) {
      console.error('Error loading gallery images:', error);
    } finally {
      setLoading(false);
    }
  };

  // Categories (simplified for Firebase integration)
  const categories = [
    { id: 'all', label: currentContent.categories.all, icon: <FaImages />, count: galleryImages.length },
  ];

  // Filter images only by category (no year/event filters anymore)
  const filteredImages = galleryImages.filter(item =>
    activeCategory === 'all' || item.category === activeCategory
  );

  const handleImageClick = (image, index) => {
    setSelectedImage(image);
    setCurrentImageIndex(index);
    setShowLightbox(true);
  };

  const nextImage = () => {
    const nextIndex = (currentImageIndex + 1) % filteredImages.length;
    setSelectedImage(filteredImages[nextIndex]);
    setCurrentImageIndex(nextIndex);
  };

  const prevImage = () => {
    const prevIndex = (currentImageIndex - 1 + filteredImages.length) % filteredImages.length;
    setSelectedImage(filteredImages[prevIndex]);
    setCurrentImageIndex(prevIndex);
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!showLightbox) return;
      if (e.key === 'Escape') setShowLightbox(false);
      if (e.key === 'ArrowRight') nextImage();
      if (e.key === 'ArrowLeft') prevImage();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showLightbox, currentImageIndex, filteredImages]);

  const getCategoryColor = (category) => {
    const colors = {
      events: 'bg-blue-100 text-blue-700',
      branches: 'bg-green-100 text-green-700',
      inauguration: 'bg-purple-100 text-purple-700',
      'customer-programs': 'bg-amber-100 text-amber-700',
      'media-coverage': 'bg-red-100 text-red-700',
      default: 'bg-gray-100 text-gray-700'
    };
    return colors[category] || colors.default;
  };

  const getEventIcon = (event) => {
    const icons = {
      anniversary: <GiPartyPopper />,
      'new-branch': <FaBuilding />,
      'customer-meet': <FaUsers />,
      festival: <FaCalendarAlt />,
      award: <GiTrophy />
    };
    return icons[event] || <FaCamera />;
  };

  return (
    <div className="font-sans bg-gradient-to-b from-gray-50 to-white min-h-screen">

      {/* Hero Banner */}
      <section
        className="relative h-[300px] sm:h-[350px] md:h-[380px] lg:h-[420px] overflow-hidden"
        style={{
          background: 'linear-gradient(rgba(26, 35, 126, 0.82), rgba(57, 73, 171, 0.78)), url("https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1920") center/cover'
        }}
      >
        <div className="relative h-full flex flex-col justify-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="flex items-center text-blue-100 text-xs sm:text-sm mb-4 sm:mb-5">
              <a href="/" className="flex items-center hover:text-white">
                <FaHome className="mr-1 sm:mr-2 text-sm sm:text-base" /> 
                <span className="hidden xs:inline">{currentContent.breadcrumbHome}</span>
                <span className="xs:hidden">Home</span>
              </a>
              <FaChevronRight className="mx-2 sm:mx-3 opacity-60 text-xs sm:text-sm" />
              <span className="font-semibold text-white text-xs sm:text-sm">{currentContent.breadcrumbGallery}</span>
            </nav>

            <div className="text-center">
              {/* Language Switcher */}
              <div className="flex justify-center mb-4 sm:mb-6">
                <div className="relative group">
                  <button className="flex items-center px-3 sm:px-4 py-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-colors text-sm">
                    <FaGlobe className="mr-1 sm:mr-2 text-blue-200 text-sm" />
                    <span className="font-medium text-xs sm:text-sm">{selectedLanguage}</span>
                    <FaCaretDown className="ml-1 sm:ml-2 text-blue-200" size={10} />
                  </button>
                  <div className="absolute right-0 mt-1 w-28 sm:w-32 bg-white rounded-md shadow-lg overflow-hidden hidden group-hover:block z-50">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => handleLanguageChange(lang.name)}
                        className="block w-full text-left px-3 sm:px-4 py-2 text-gray-800 hover:bg-blue-50 hover:text-blue-600 transition-colors text-xs sm:text-sm"
                      >
                        {lang.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-3 sm:mb-4">
                {currentContent.title} <span className="bg-gradient-to-r from-blue-200 to-cyan-200 bg-clip-text text-transparent">{currentContent.titleHighlight}</span>
              </h1>
              <p className="text-sm sm:text-base md:text-lg lg:text-xl text-blue-100 max-w-2xl mx-auto px-4">
                {currentContent.subtitle}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Category Tabs + Gallery */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 md:py-12">

        {/* Category Navigation */}
        <div className="mb-6 sm:mb-8 lg:mb-10">
          <div className="flex overflow-x-auto pb-2 sm:pb-4 gap-2 sm:gap-3 scrollbar-hide">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center px-3 sm:px-4 lg:px-5 py-2 sm:py-3 rounded-lg sm:rounded-xl whitespace-nowrap transition-all flex-shrink-0 text-xs sm:text-sm ${
                  activeCategory === cat.id
                    ? 'bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg'
                    : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span className="mr-1 sm:mr-2 text-sm sm:text-lg">{cat.icon}</span>
                <span className="hidden xs:inline">{cat.label}</span>
                <span className={`ml-2 sm:ml-3 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-xs font-semibold ${
                  activeCategory === cat.id ? 'bg-white/25 text-white' : 'bg-blue-50 text-blue-700'
                }`}>
                  {cat.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Photo Gallery Section */}
        <section>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 sm:mb-8">
            <div>
              <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-gray-800">
                {activeCategory === 'all' ? currentContent.allPhotos : `${categories.find(c => c.id === activeCategory)?.label} ${currentContent.photos}`}
              </h2>
              <p className="text-gray-600 mt-1 sm:mt-1.5 text-sm sm:text-base">
                {filteredImages.length} {filteredImages.length === 1 ? currentContent.image : currentContent.images}
              </p>
            </div>
          </div>

          {filteredImages.length === 0 ? (
            <div className="text-center py-12 sm:py-16 lg:py-20">
              <FaCamera className="mx-auto text-4xl sm:text-5xl lg:text-6xl text-gray-300 mb-3 sm:mb-5" />
              <h3 className="text-lg sm:text-xl lg:text-2xl font-semibold text-gray-700 mb-2 sm:mb-3">{currentContent.noImagesFound}</h3>
              <p className="text-gray-500 text-sm sm:text-base px-4">{currentContent.tryDifferentCategory}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 md:gap-6 lg:gap-7">
              {filteredImages.map((image, idx) => (
                <div
                  key={image.id}
                  className="group relative rounded-lg sm:rounded-xl lg:rounded-2xl overflow-hidden bg-white shadow-md border border-gray-200 hover:shadow-xl hover:border-blue-200 transition-all duration-300 cursor-pointer"
                  onClick={() => handleImageClick(image, idx)}
                >
                  <div className="relative h-48 sm:h-56 md:h-64 overflow-hidden">
                    <img
                      src={image.url}
                      alt={image.originalName || 'Gallery image'}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="bg-white/90 rounded-full p-3 sm:p-4 lg:p-5 shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                        <FaExpand className="text-blue-600 text-lg sm:text-xl lg:text-2xl" />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Lightbox */}
      {showLightbox && selectedImage && (
        <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-2 sm:p-4">
          <button
            onClick={() => setShowLightbox(false)}
            className="absolute top-3 sm:top-4 md:top-6 right-3 sm:right-4 md:right-6 text-white text-2xl sm:text-3xl md:text-4xl hover:text-gray-300 z-20"
          >
            <FaTimes />
          </button>

          <button
            onClick={prevImage}
            className="absolute left-2 sm:left-4 md:left-5 lg:left-10 top-1/2 -translate-y-1/2 text-white text-2xl sm:text-3xl md:text-4xl p-2 sm:p-3 md:p-4 rounded-full bg-black/40 hover:bg-black/60 z-20"
          >
            <FaChevronLeft />
          </button>

          <button
            onClick={nextImage}
            className="absolute right-2 sm:right-4 md:right-5 lg:right-10 top-1/2 -translate-y-1/2 text-white text-2xl sm:text-3xl md:text-4xl p-2 sm:p-3 md:p-4 rounded-full bg-black/40 hover:bg-black/60 z-20"
          >
            <FaChevronRightIcon />
          </button>

          <div className="relative max-w-4xl lg:max-w-5xl max-h-[70vh] sm:max-h-[75vh] md:max-h-[80vh] lg:max-h-[85vh] w-full">
            <img
              src={selectedImage.url}
              alt={selectedImage.originalName || 'Gallery image'}
              className="max-w-full max-h-[60vh] sm:max-h-[65vh] md:max-h-[70vh] lg:max-h-[80vh] object-contain rounded-lg mx-auto"
            />
          </div>
        </div>
      )}

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default GalleryPage;