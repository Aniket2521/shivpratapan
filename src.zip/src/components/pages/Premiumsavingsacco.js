import React, { useState } from 'react';
import { 
  FaCrown, FaGem, FaStar, FaShieldAlt, FaPhoneAlt,
  FaEnvelope, FaMapMarkerAlt, FaDownload, FaFileAlt,
  FaUserCheck, FaIdCard, FaPercent, FaCalculator,
  FaMobileAlt, FaQrcode, FaExchangeAlt, FaWallet,
  FaCreditCard, FaBell, FaLock, FaUserTie,
  FaHandHoldingUsd, FaChevronRight, FaHome,
  FaArrowRight, FaCheckCircle, FaClock,
  FaChartLine, FaHandshake, FaAward, FaBuilding,
  FaRupeeSign, FaUsers, FaGlobe, FaHeadset, FaUniversity, FaInfoCircle
} from 'react-icons/fa';
import { GiCash, GiReceiveMoney, GiPayMoney } from 'react-icons/gi';

const Premiumsavingsacco = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [balance, setBalance] = useState(100000);
  const [interestRate] = useState(6.50);

  // Calculate interest
  const calculateInterest = (amount) => {
    return (amount * interestRate) / 100;
  };

  // Quick menu items
  const quickMenuItems = [
    { id: 'overview', label: 'Account Overview', icon: <FaGem /> },
    { id: 'features', label: 'Premium Features', icon: <FaStar /> },
    { id: 'interest', label: 'Interest Rate', icon: <FaPercent /> },
    { id: 'eligibility', label: 'Eligibility', icon: <FaUserCheck /> },
    { id: 'documents', label: 'Documents', icon: <FaIdCard /> },
    { id: 'faq', label: 'FAQs', icon: <FaFileAlt /> }
  ];

  // Premium Features
  const premiumFeatures = [
    {
      marathi: 'पैसे काढणे',
      english: 'Cash Withdrawal',
      description: 'Priority cash withdrawal with dedicated counters',
      icon: <GiReceiveMoney />,
      color: 'from-amber-500 to-amber-700'
    },
    {
      marathi: 'पैसे जमा करणे',
      english: 'Cash Deposit',
      description: 'Enhanced deposit limits and quick processing',
      icon: <GiPayMoney />,
      color: 'from-emerald-500 to-emerald-700'
    },
    {
      marathi: 'NEFT / RTGS / IMPS',
      english: 'Instant Transfers',
      description: 'Higher transaction limits and free fund transfers',
      icon: <FaExchangeAlt />,
      color: 'from-blue-500 to-blue-700'
    },
    {
      marathi: 'मोबाईल बँकिंग',
      english: 'Free Mobile Banking',
      description: 'Unlimited access to premium mobile banking',
      icon: <FaMobileAlt />,
      color: 'from-purple-500 to-purple-700'
    },
    {
      marathi: 'QR कोड बँकिंग',
      english: 'QR Code Banking',
      description: 'Secure QR-based payments and transactions',
      icon: <FaQrcode />,
      color: 'from-teal-500 to-teal-700'
    },
    {
      marathi: 'प्राधान्यक्रम सेवा',
      english: 'Priority Service',
      description: 'Dedicated relationship manager and priority support',
      icon: <FaHeadset />,
      color: 'from-rose-500 to-rose-700'
    }
  ];

  // Additional Premium Benefits
  const additionalBenefits = [
    { title: 'Premium Support', icon: <FaUserTie />, desc: '24/7 dedicated relationship manager' },
    { title: 'E-Statements', icon: <FaEnvelope />, desc: 'Monthly comprehensive statements' },
    { title: 'Nomination', icon: <FaUsers />, desc: 'Multiple nomination facility' },
    { title: 'Instant Alerts', icon: <FaBell />, desc: 'Real-time SMS & email alerts' },
    { title: 'Enhanced Security', icon: <FaLock />, desc: 'Advanced fraud protection' },
    { title: 'Global Access', icon: <FaGlobe />, desc: 'Worldwide ATM access' }
  ];

  // Eligibility Criteria
  const eligibilityCriteria = [
    { requirement: 'Resident Individual', status: true },
    { requirement: 'Minimum Age: 21 years', status: true },
    { requirement: 'Minimum Balance: ₹50,000', status: true },
    { requirement: 'Annual Income: ₹6 Lakhs+', status: true },
    { requirement: 'Existing Bank Customer', status: false }
  ];

  // Required Documents
  const requiredDocuments = [
    { document: 'Aadhaar Card', mandatory: true },
    { document: 'PAN Card', mandatory: true },
    { document: 'Address Proof', mandatory: true },
    { document: 'Income Proof (Salary Slip/ITR)', mandatory: true },
    { document: 'Passport Photos', mandatory: true },
    { document: 'Signature Specimen', mandatory: true }
  ];

  // Premium Charges
  const premiumCharges = [
    { service: 'Account Maintenance', charge: '₹999', period: 'Annual' },
    { service: 'ATM Transactions', charge: 'Free', period: 'Unlimited' },
    { service: 'Fund Transfers', charge: 'Free', period: 'All Channels' },
    { service: 'Cheque Book', charge: 'Free', period: 'Annual' },
    { service: 'SMS Alerts', charge: 'Free', period: 'Lifetime' }
  ];

  // FAQ Items
  const faqItems = [
    {
      question: 'What makes Premium Savings Account different?',
      answer: 'Premium account offers higher interest rates, priority services, dedicated relationship manager, enhanced transaction limits, and exclusive banking privileges.'
    },
    {
      question: 'What is the minimum balance requirement?',
      answer: 'Minimum quarterly average balance requirement is ₹50,000. Non-maintenance charges apply if balance falls below this.'
    },
    {
      question: 'Can I convert my regular account to premium?',
      answer: 'Yes, existing customers can upgrade by maintaining the required balance and submitting an upgrade request.'
    },
    {
      question: 'Are there any hidden charges?',
      answer: 'No hidden charges. All fees are transparently communicated upfront. Annual maintenance fee of ₹999 applies.'
    }
  ];

  // Handle scroll to section
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
    }
  };

  return (
    <div className="font-sans bg-gradient-to-b from-gray-50 to-white">
      {/* 1. Premium Hero Banner */}
      <section 
        className="relative h-[500px] overflow-hidden"
        style={{
          background: 'linear-gradient(rgba(21, 21, 21, 0.9), rgba(42, 42, 42, 0.85)), url("https://images.unsplash.com/photo-1616514197671-15d99ce7a6f8?auto=format&fit=crop&w=1920")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        {/* Gold Overlay Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23FFD700' fill-opacity='0.4' fill-rule='evenodd'/%3E%3C/svg%3E")`,
            backgroundSize: '300px'
          }}></div>
        </div>

        <div className="relative h-full flex flex-col justify-center">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Premium Badge */}
            <div className="flex items-center mb-6">
              <div className="bg-gradient-to-r from-amber-500 to-yellow-500 text-black px-4 py-2 rounded-full font-bold flex items-center">
                <FaCrown className="mr-2" />
                PREMIUM BANKING
              </div>
            </div>

            {/* Breadcrumb */}
            <nav className="flex items-center text-gray-300 text-sm mb-8">
              <a href="/" className="flex items-center hover:text-white transition-colors">
                <FaHome className="mr-2" />
                Home
              </a>
              <FaChevronRight className="mx-2 opacity-50" />
              <a href="/account" className="hover:text-white transition-colors">Account</a>
              <FaChevronRight className="mx-2 opacity-50" />
              <span className="font-semibold text-white">Premium Savings Account</span>
            </nav>

            {/* Main Heading */}
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-4">
              Premium Savings <span className="bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent">Account</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mb-8">
              Higher returns. Smarter banking. <span className="text-amber-300 font-semibold">Premium benefits.</span>
            </p>

            {/* Premium Stats */}
            <div className="flex flex-wrap gap-6 mt-8">
              <div className="bg-gradient-to-r from-amber-900/30 to-yellow-900/30 backdrop-blur-sm rounded-xl px-6 py-4 border border-amber-500/20">
                <div className="text-amber-200 text-sm opacity-90">Interest Rate</div>
                <div className="text-3xl font-bold text-amber-300">6.50% p.a.</div>
              </div>
              <div className="bg-gradient-to-r from-emerald-900/30 to-green-900/30 backdrop-blur-sm rounded-xl px-6 py-4 border border-emerald-500/20">
                <div className="text-emerald-200 text-sm opacity-90">Min Balance</div>
                <div className="text-3xl font-bold text-emerald-300">₹50,000</div>
              </div>
              <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 backdrop-blur-sm rounded-xl px-6 py-4 border border-blue-500/20">
                <div className="text-blue-200 text-sm opacity-90">Premium Services</div>
                <div className="text-3xl font-bold text-blue-300">25+</div>
              </div>
            </div>
          </div>
        </div>

        {/* Shiny Border Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-transparent via-amber-500 to-transparent"></div>
      </section>

      {/* 2. Premium Quick Navigation */}
      <section className="sticky top-0 z-40 bg-gradient-to-r from-gray-900 to-gray-800 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto py-4 space-x-2 scrollbar-hide">
            {quickMenuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`flex items-center px-6 py-3 rounded-xl whitespace-nowrap transition-all duration-300 transform hover:-translate-y-1 ${
                  activeSection === item.id
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-gray-900 shadow-lg shadow-amber-500/30'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <span className="mr-3 text-lg">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* 3. About Premium Account */}
            <section id="overview" className="scroll-mt-24">
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl shadow-2xl p-8 border border-gray-700">
                <div className="flex items-center mb-8">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 flex items-center justify-center mr-6">
                    <FaCrown className="text-gray-900 text-2xl" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-white">About Premium Savings Account</h2>
                    <p className="text-gray-400">Exclusive banking for exceptional individuals</p>
                  </div>
                </div>

                <div className="space-y-6 text-gray-300">
                  <p className="text-lg">
                    The <span className="text-amber-300 font-semibold">Premium Savings Account</span> is designed 
                    for discerning customers who seek more than just basic banking. It combines the security of 
                    traditional savings with the sophistication of premium financial services.
                  </p>
                  <p>
                    Tailored for professionals, business owners, and high-net-worth individuals, this account 
                    offers enhanced interest rates, priority services, and exclusive benefits that elevate your 
                    banking experience. Enjoy the perfect blend of growth, security, and convenience with our 
                    premium offerings.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
                  <div className="bg-gradient-to-br from-amber-900/30 to-yellow-900/30 rounded-2xl p-6 border border-amber-500/20">
                    <h4 className="font-bold text-white mb-4 flex items-center">
                      <FaUserTie className="text-amber-400 mr-3" />
                      Ideal For
                    </h4>
                    <ul className="space-y-3">
                      {['Professionals & Executives', 'Business Owners', 'Senior Citizens', 'High-Income Earners'].map((item, idx) => (
                        <li key={idx} className="flex items-center text-gray-300">
                          <div className="w-2 h-2 bg-amber-500 rounded-full mr-3"></div>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-gradient-to-br from-blue-900/30 to-cyan-900/30 rounded-2xl p-6 border border-blue-500/20">
                    <h4 className="font-bold text-white mb-4 flex items-center">
                      <FaShieldAlt className="text-blue-400 mr-3" />
                      Exclusive Privileges
                    </h4>
                    <ul className="space-y-3">
                      {['Priority Banking Services', 'Higher Transaction Limits', 'Dedicated Manager', 'Waived Off Charges'].map((item, idx) => (
                        <li key={idx} className="flex items-center text-gray-300">
                          <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* 4. Premium Features */}
            <section id="features" className="scroll-mt-24">
              <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-200">
                <div className="flex items-center justify-between mb-10">
                  <div>
                    <h2 className="text-3xl font-bold text-gray-900">Premium Features</h2>
                    <p className="text-gray-600">Experience banking like never before</p>
                  </div>
                  <div className="bg-gradient-to-r from-amber-500 to-yellow-500 text-gray-900 px-4 py-2 rounded-full font-bold">
                    EXCLUSIVE
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {premiumFeatures.map((feature, index) => (
                    <div 
                      key={index}
                      className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-white to-gray-50 p-6 border border-gray-300 hover:border-amber-300 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl"
                    >
                      {/* Shine Effect */}
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                      
                      <div className="flex flex-col items-center text-center">
                        <div className={`w-20 h-20 rounded-2xl bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                          <div className="text-white text-3xl">
                            {feature.icon}
                          </div>
                        </div>
                        <h3 className="font-bold text-gray-900 text-lg mb-2">{feature.english}</h3>
                        <p className="text-amber-700 font-medium text-sm mb-2">{feature.marathi}</p>
                        <p className="text-gray-600 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* 5. Interest Rate Highlight */}
            <section id="interest" className="scroll-mt-24">
              <div className="relative overflow-hidden rounded-3xl shadow-2xl">
                <div 
                  className="absolute inset-0 opacity-10"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23FFD700' fill-opacity='0.3'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
                  }}
                ></div>
                
                <div className="relative bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 p-12 text-center">
                  <div className="max-w-3xl mx-auto">
                    <div className="flex items-center justify-center mb-6">
                      <FaPercent className="text-gray-900 text-4xl mr-4" />
                      <h2 className="text-4xl font-bold text-gray-900">Premium Interest Rate</h2>
                    </div>
                    
                    <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-3xl p-8 mb-8">
                      <div className="text-6xl md:text-7xl font-bold text-gray-900 mb-4">
                        6.50% <span className="text-3xl">per annum</span>
                      </div>
                      <div className="text-xl text-gray-800 font-semibold">
                        Higher returns compared to regular savings accounts
                      </div>
                    </div>

                    {/* Interest Calculator */}
                    <div className="bg-white bg-opacity-30 backdrop-blur-sm rounded-3xl p-8">
                      <h3 className="text-2xl font-bold text-gray-900 mb-6">Calculate Your Earnings</h3>
                      <div className="space-y-6">
                        <div>
                          <label className="block text-gray-900 font-bold mb-3">
                            Enter Balance Amount (₹)
                          </label>
                          <div className="relative">
                            <input
                              type="range"
                              min="50000"
                              max="10000000"
                              step="10000"
                              value={balance}
                              onChange={(e) => setBalance(parseInt(e.target.value))}
                              className="w-full h-3 bg-gray-900 bg-opacity-30 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-gray-900 [&::-webkit-slider-thumb]:border-4 [&::-webkit-slider-thumb]:border-white"
                            />
                            <div className="flex justify-between text-sm text-gray-900 mt-2 font-bold">
                              <span>₹50,000</span>
                              <span>₹1 Crore</span>
                            </div>
                          </div>
                          <div className="text-center mt-4">
                            <div className="text-3xl font-bold text-gray-900">
                              ₹{balance.toLocaleString()}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="bg-gray-900 bg-opacity-40 rounded-2xl p-6">
                            <div className="text-gray-200 mb-2">Yearly Interest</div>
                            <div className="text-4xl font-bold text-white">
                              ₹{calculateInterest(balance).toLocaleString(undefined, {minimumFractionDigits: 2})}
                            </div>
                          </div>
                          <div className="bg-gray-900 bg-opacity-40 rounded-2xl p-6">
                            <div className="text-gray-200 mb-2">Monthly Interest</div>
                            <div className="text-4xl font-bold text-white">
                              ₹{(calculateInterest(balance) / 12).toLocaleString(undefined, {minimumFractionDigits: 2})}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 6. Additional Premium Benefits */}
            <section className="scroll-mt-24">
              <div className="bg-gradient-to-br from-emerald-900 to-teal-800 rounded-3xl shadow-2xl p-10 border border-emerald-700">
                <div className="flex items-center mb-10">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 flex items-center justify-center mr-6">
                    <FaAward className="text-white text-2xl" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-white">Additional Premium Benefits</h2>
                    <p className="text-emerald-200">Exclusive privileges for premium customers</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {additionalBenefits.map((benefit, index) => (
                    <div 
                      key={index}
                      className="bg-gradient-to-br from-emerald-800/50 to-teal-800/50 rounded-2xl p-6 border border-emerald-600/30 hover:border-emerald-400 transition-all duration-300 hover:scale-105 group"
                    >
                      <div className="flex flex-col items-center text-center">
                        <div className="w-16 h-16 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 flex items-center justify-center mb-4 group-hover:rotate-12 transition-transform duration-300">
                          <div className="text-white text-2xl">
                            {benefit.icon}
                          </div>
                        </div>
                        <h3 className="font-bold text-white text-lg mb-3">{benefit.title}</h3>
                        <p className="text-emerald-200 text-sm">{benefit.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* 7. Eligibility & Documentation */}
            <section id="eligibility" className="scroll-mt-24">
              <div className="bg-white rounded-3xl shadow-2xl p-10 border border-gray-200">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  {/* Eligibility */}
                  <div>
                    <div className="flex items-center mb-8">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mr-5">
                        <FaUserCheck className="text-white text-xl" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-gray-900">Eligibility Criteria</h2>
                        <p className="text-gray-600">Who qualifies for premium banking</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {eligibilityCriteria.map((item, index) => (
                        <div key={index} className="flex items-center p-4 rounded-xl bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200">
                          {item.status ? (
                            <FaCheckCircle className="text-green-500 mr-4 flex-shrink-0 text-xl" />
                          ) : (
                            <FaInfoCircle className="text-blue-500 mr-4 flex-shrink-0 text-xl" />
                          )}
                          <span className="text-gray-800 font-medium">{item.requirement}</span>
                          {item.status && (
                            <span className="ml-auto bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold">
                              REQUIRED
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Documentation */}
                  <div id="documents" className="scroll-mt-24">
                    <div className="flex items-center mb-8">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mr-5">
                        <FaIdCard className="text-white text-xl" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-bold text-gray-900">Required Documents</h2>
                        <p className="text-gray-600">KYC documentation for premium account</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {requiredDocuments.map((doc, index) => (
                        <div key={index} className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 hover:border-purple-300 transition-colors">
                          <div className="flex items-center">
                            <FaFileAlt className="text-purple-600 mr-4 flex-shrink-0" />
                            <span className="text-gray-800 font-medium">{doc.document}</span>
                          </div>
                          {doc.mandatory ? (
                            <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3 py-1 rounded-full text-xs font-bold">
                              MANDATORY
                            </span>
                          ) : (
                            <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs">
                              OPTIONAL
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Premium Charges Table */}
                <div className="mt-12 pt-10 border-t border-gray-200">
                  <div className="flex items-center mb-8">
                    <FaRupeeSign className="text-gray-700 text-2xl mr-4" />
                    <h3 className="text-2xl font-bold text-gray-900">Premium Account Charges</h3>
                  </div>
                  
                  <div className="overflow-hidden rounded-2xl border border-gray-200">
                    <table className="w-full">
                      <thead className="bg-gradient-to-r from-gray-900 to-gray-800">
                        <tr>
                          <th className="py-4 px-6 text-left text-white font-bold">Service</th>
                          <th className="py-4 px-6 text-left text-white font-bold">Charge</th>
                          <th className="py-4 px-6 text-left text-white font-bold">Period</th>
                        </tr>
                      </thead>
                      <tbody>
                        {premiumCharges.map((charge, index) => (
                          <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                            <td className="py-4 px-6 text-gray-800 font-medium">{charge.service}</td>
                            <td className="py-4 px-6">
                              <span className={`px-3 py-1 rounded-full font-bold ${
                                charge.charge === 'Free' 
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-amber-100 text-amber-700'
                              }`}>
                                {charge.charge}
                              </span>
                            </td>
                            <td className="py-4 px-6 text-gray-600">{charge.period}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </section>

            {/* FAQ Section */}
            <section id="faq" className="scroll-mt-24">
              <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl shadow-2xl p-10 border border-gray-700">
                <div className="flex items-center mb-10">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center mr-6">
                    <FaFileAlt className="text-white text-2xl" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-white">Frequently Asked Questions</h2>
                    <p className="text-gray-400">Get answers to common premium banking queries</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {faqItems.map((item, index) => (
                    <div key={index} className="border border-gray-700 rounded-2xl overflow-hidden bg-gray-800/50">
                      <button
                        onClick={() => {
                          const element = document.getElementById(`premium-faq-${index}`);
                          if (element) {
                            element.classList.toggle('hidden');
                          }
                        }}
                        className="w-full flex items-center justify-between p-6 bg-gray-900/30 hover:bg-gray-800 transition-colors"
                      >
                        <h3 className="text-lg font-semibold text-white text-left pr-4">{item.question}</h3>
                        <FaChevronRight className="text-gray-400 transition-transform flex-shrink-0" />
                      </button>
                      <div id={`premium-faq-${index}`} className="hidden p-6 border-t border-gray-700">
                        <p className="text-gray-300">{item.answer}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-8">
            {/* Premium Apply Now Card */}
            <div className="relative overflow-hidden rounded-3xl shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black"></div>
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-amber-500/20 to-transparent rounded-full -mr-16 -mt-16"></div>
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-yellow-500/20 to-transparent rounded-full -ml-16 -mb-16"></div>
              
              <div className="relative p-8 text-white">
                <div className="flex items-center mb-6">
                  <FaCrown className="text-amber-300 text-3xl mr-3" />
                  <h3 className="text-2xl font-bold">Upgrade to Premium</h3>
                </div>
                <p className="text-gray-300 mb-8">
                  Experience premium banking with exclusive benefits and higher returns
                </p>
                
                <div className="space-y-4 mb-8">
                  <button className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-gray-900 py-4 rounded-xl font-bold text-lg hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-300 transform hover:-translate-y-1">
                    Apply Now
                  </button>
                  <button className="w-full bg-gray-800 text-white py-4 rounded-xl font-bold text-lg hover:bg-gray-700 transition-colors border border-gray-700">
                    <FaPhoneAlt className="inline mr-2" />
                    Call Relationship Manager
                  </button>
                  <button className="w-full bg-transparent text-white py-4 rounded-xl font-bold text-lg hover:bg-gray-800 transition-colors border border-gray-700">
                    <FaDownload className="inline mr-2" />
                    Download Application
                  </button>
                </div>

                <div className="space-y-4 pt-6 border-t border-gray-700">
                  <div className="flex items-center">
                    <FaClock className="text-amber-300 mr-3" />
                    <div>
                      <div className="font-semibold">Priority Processing</div>
                      <div className="text-sm text-gray-400">24-48 hours approval</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <FaHandshake className="text-amber-300 mr-3" />
                    <div>
                      <div className="font-semibold">Dedicated Manager</div>
                      <div className="text-sm text-gray-400">Personal relationship manager</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Premium Quick Links */}
            <div className="bg-white rounded-3xl shadow-xl p-6 border border-gray-200">
              <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
                <FaStar className="text-amber-500 mr-3" />
                Premium Services
              </h3>
              <div className="space-y-3">
                <a href="#" className="flex items-center p-4 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mr-4">
                    <FaChartLine className="text-white" />
                  </div>
                  <span className="font-medium text-gray-800">Wealth Management</span>
                </a>
                <a href="#" className="flex items-center p-4 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-emerald-500 to-green-500 flex items-center justify-center mr-4">
                    <FaHandHoldingUsd className="text-white" />
                  </div>
                  <span className="font-medium text-gray-800">Premium Loans</span>
                </a>
                <a href="#" className="flex items-center p-4 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mr-4">
                    <FaUniversity className="text-white" />
                  </div>
                  <span className="font-medium text-gray-800">Priority FDs</span>
                </a>
                <a href="#" className="flex items-center p-4 rounded-xl hover:bg-gray-50 transition-colors border border-gray-100">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 flex items-center justify-center mr-4">
                    <FaCreditCard className="text-white" />
                  </div>
                  <span className="font-medium text-gray-800">Premium Cards</span>
                </a>
              </div>
            </div>

            {/* Premium Contact Card */}
            <div className="bg-gradient-to-br from-blue-900 to-blue-800 rounded-3xl shadow-xl p-6 border border-blue-700">
              <h3 className="text-xl font-bold text-white mb-6">Premium Support</h3>
              <div className="space-y-4">
                <div className="flex items-center p-4 bg-blue-800/30 rounded-xl border border-blue-700">
                  <FaHeadset className="text-blue-300 text-2xl mr-4" />
                  <div>
                    <div className="font-medium text-white">24/7 Premium Helpline</div>
                    <div className="text-blue-200 font-bold text-lg">1800-258-7890</div>
                  </div>
                </div>
                <div className="flex items-center p-4 bg-blue-800/30 rounded-xl border border-blue-700">
                  <FaMapMarkerAlt className="text-blue-300 text-2xl mr-4" />
                  <div>
                    <div className="font-medium text-white">Premium Lounge</div>
                    <div className="text-blue-200">Visit our exclusive lounge</div>
                  </div>
                </div>
                <div className="flex items-center p-4 bg-blue-800/30 rounded-xl border border-blue-700">
                  <FaEnvelope className="text-blue-300 text-2xl mr-4" />
                  <div>
                    <div className="font-medium text-white">Email Support</div>
                    <div className="text-blue-200">premium@shivpratapbank.com</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 8. Premium CTA Banner */}
        <section id="apply" className="scroll-mt-24 mt-16">
          <div 
            className="relative overflow-hidden rounded-3xl shadow-2xl"
            style={{
              background: 'linear-gradient(135deg, rgba(21, 21, 21, 0.95) 0%, rgba(42, 42, 42, 0.9) 100%)',
              border: '1px solid rgba(255, 215, 0, 0.2)'
            }}
          >
            {/* Animated Gold Particles */}
            <div className="absolute inset-0 overflow-hidden">
              {[...Array(20)].map((_, i) => (
                <div 
                  key={i}
                  className="absolute w-2 h-2 bg-amber-400 rounded-full animate-pulse"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    animationDelay: `${Math.random() * 2}s`,
                    opacity: Math.random() * 0.5 + 0.2
                  }}
                />
              ))}
            </div>

            <div className="relative p-12 text-center text-white z-10">
              <div className="max-w-3xl mx-auto">
                <FaCrown className="text-amber-400 text-5xl mb-6 mx-auto" />
                <h2 className="text-4xl md:text-5xl font-bold mb-6">
                  Upgrade to <span className="bg-gradient-to-r from-amber-400 to-yellow-500 bg-clip-text text-transparent">Premium</span> Today
                </h2>
                <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
                  Join the elite group of customers who enjoy premium banking benefits, higher returns, and exclusive services
                </p>
                
                <div className="flex flex-col sm:flex-row gap-6 justify-center">
                  <button className="bg-gradient-to-r from-amber-500 to-yellow-500 text-gray-900 px-10 py-5 rounded-full font-bold text-xl hover:shadow-2xl hover:shadow-amber-500/40 transition-all duration-300 transform hover:-translate-y-2">
                    Apply for Premium Account
                  </button>
                  <button className="bg-transparent border-2 border-amber-500 text-amber-400 px-10 py-5 rounded-full font-bold text-xl hover:bg-amber-500 hover:bg-opacity-10 transition-all duration-300">
                    Schedule Branch Visit
                  </button>
                </div>
                
                <div className="mt-10 pt-8 border-t border-gray-700">
                  <div className="flex flex-wrap justify-center gap-8">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-amber-300">6.50%</div>
                      <div className="text-gray-400">Interest Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-amber-300">₹50K</div>
                      <div className="text-gray-400">Min Balance</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-amber-300">24/7</div>
                      <div className="text-gray-400">Premium Support</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-amber-300">0</div>
                      <div className="text-gray-400">Hidden Charges</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Custom CSS */}
      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 0.2; }
          50% { opacity: 0.8; }
        }
        
        .animate-pulse {
          animation: pulse 2s infinite;
        }
        
        /* Custom slider thumb */
        input[type="range"]::-webkit-slider-thumb {
          appearance: none;
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: #1f2937;
          border: 4px solid white;
          cursor: pointer;
          box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }
        
        input[type="range"]::-moz-range-thumb {
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: #1f2937;
          border: 4px solid white;
          cursor: pointer;
          box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }
      `}</style>
    </div>
  );
};

export default Premiumsavingsacco;