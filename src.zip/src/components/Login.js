import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FaSignInAlt, 
  FaEnvelope, 
  FaLock, 
  FaEye, 
  FaEyeSlash,
  FaShieldAlt,
  FaBuilding,
  FaUserPlus
} from 'react-icons/fa';
import { database, ref, get, set, push } from '../firebase';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    
    setLoading(true);
    setError('');

    try {
      // Validation
      if (!email || !password) {
        throw new Error('Please enter both email and password');
      }

      // Check if email+password exists in Firebase Realtime Database
      const adminRef = ref(database, 'shivpratapmultistate/Admin');
      const snapshot = await get(adminRef);

      if (!snapshot.exists()) {
        throw new Error('Mail not present');
      }

      // Search for user with matching email
      const adminData = snapshot.val();
      let foundUser = null;
      let foundUserId = null;

      // Loop through all admin users to find matching email + password
      for (const userId in adminData) {
        const row = adminData?.[userId];
        const rowEmail = row?.email;
        const rowPassword = row?.password;


        // NOTE: This compares plaintext password stored in DB.
        // Not recommended for production, but implemented as requested.
        const emailMatches =
          typeof rowEmail === 'string' && rowEmail.toLowerCase() === email.toLowerCase();
        const passwordMatches = typeof rowPassword === 'string' && rowPassword === password;

        if (emailMatches && passwordMatches) {
          foundUser = row;
          foundUserId = userId;
          break;
        }
      }

      // If email not found in database, show error
      if (!foundUser) {
        throw new Error('Mail/password not present');
      }

      // Update last login time
      const updateData = {
        ...foundUser,
        lastLogin: new Date().toISOString()
      };
      await set(ref(database, `shivpratapmultistate/Admin/${foundUserId}`), updateData);

      // Store login state
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('adminEmail', foundUser.email || email);
      localStorage.setItem('adminName', foundUser.email?.split('@')[0] || 'Administrator');
      localStorage.setItem('adminUid', foundUserId);

      navigate('/admin-dashboard');
      
    } catch (err) {
      // Handle Firebase authentication errors
      let errorMessage = 'Login failed. Please try again.';
      
      if (err.message === 'Mail not present') {
        errorMessage = 'Mail not present';
      } else if (err.message === 'Mail/password not present') {
        errorMessage = 'Mail/password not present';
      } else if (err.message) {
        errorMessage = err.message;
      }
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccessMessage('');

    try {
      // Validation
      if (!email || !password) {
        throw new Error('Please enter both email and password');
      }

      if (!email.includes('@')) {
        throw new Error('Please enter a valid email address');
      }

      if (password.length < 6) {
        throw new Error('Password must be at least 6 characters long');
      }

      // Check if email already exists in database
      const adminRef = ref(database, 'shivpratapmultistate/Admin');
      const snapshot = await get(adminRef);

      if (snapshot.exists()) {
        const adminData = snapshot.val();
        for (const userId in adminData) {
          if (adminData[userId] && adminData[userId].email && 
              adminData[userId].email.toLowerCase() === email.toLowerCase()) {
            throw new Error('Email already registered. Please use a different email.');
          }
        }
      }

      // Store user data in Firebase Realtime Database
      // NOTE: Storing plaintext passwords is NOT recommended for production.
      // Implemented as requested.
      const userData = {
        email: email,
        password: password,
        createdAt: new Date().toISOString(),
        lastLogin: null,
        status: 'active'
      };

      // Store under shivpratapmultistate/Admin node (auto id)
      const newRef = await push(ref(database, 'shivpratapmultistate/Admin'));
      await set(newRef, { ...userData, uid: newRef.key });

      setSuccessMessage('Registration successful! You can now login.');
      
      // Reset form and switch to login mode after 2 seconds
      setTimeout(() => {
        setEmail('');
        setPassword('');
        setIsRegisterMode(false);
        setSuccessMessage('');
      }, 2000);

    } catch (err) {
      // Handle Firebase authentication errors
      let errorMessage = 'Registration failed. Please try again.';
      
      if (err.message) {
        errorMessage = err.message;
      }
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const containerStyle = {
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    minHeight: '100vh'
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row" style={containerStyle}>
      {/* Left Side - Brand/Info */}
      <div className="hidden md:flex md:w-1/2 flex-col justify-between p-12 text-white">
        <div>
          <div className="flex items-center mb-8">
            <FaBuilding className="text-4xl mr-3" />
            <div>
              <h1 className="text-3xl font-bold">Shiv Pratap</h1>
              <p className="text-white/80">Multistate Admin Portal</p>
            </div>
          </div>
          
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Admin Dashboard Access</h2>
            <div className="space-y-4">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mr-3">
                  <span className="text-sm">✓</span>
                </div>
                <span>Full administrative control</span>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mr-3">
                  <span className="text-sm">✓</span>
                </div>
                <span>Real-time analytics & reports</span>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mr-3">
                  <span className="text-sm">✓</span>
                </div>
                <span>User management system</span>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mr-3">
                  <span className="text-sm">✓</span>
                </div>
                <span>Secure data encryption</span>
              </div>
            </div>
          </div>
        </div>

        <div className="text-white/60 text-sm">
          <p>Version 2.5.1 • Secure Portal</p>
          <p className="mt-2">© 2024 Shiv Pratap Multistate. All rights reserved.</p>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full md:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile Header */}
          <div className="md:hidden text-center mb-10">
            <div className="flex items-center justify-center mb-4">
              <FaBuilding className="text-3xl text-white mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-white">Shiv Pratap</h1>
                <p className="text-white/80">Multistate Admin</p>
              </div>
            </div>
          </div>

          {/* Login Card */}
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mb-4">
                {isRegisterMode ? (
                  <FaUserPlus className="w-8 h-8 text-white" />
                ) : (
                  <FaShieldAlt className="w-8 h-8 text-white" />
                )}
              </div>
              <h2 className="text-2xl font-bold text-white">
                {isRegisterMode ? 'Admin Registration' : 'Admin Login'}
              </h2>
              <p className="text-white/70 mt-2">
                {isRegisterMode ? 'Create a new admin account' : 'Enter your credentials to continue'}
              </p>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-500/20 border border-red-500/30 rounded-lg">
                <p className="text-red-200 text-sm text-center">{error}</p>
              </div>
            )}

            {successMessage && (
              <div className="mb-6 p-4 bg-green-500/20 border border-green-500/30 rounded-lg">
                <p className="text-green-200 text-sm text-center">{successMessage}</p>
              </div>
            )}

            <form onSubmit={isRegisterMode ? handleRegister : handleLogin}>
              <div className="space-y-6">
                {/* Email Field */}
                <div>
                  <label className="block text-white/90 mb-2 text-sm font-medium">
                    <div className="flex items-center">
                      <FaEnvelope className="mr-2" />
                      Email Address
                    </div>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    required
                  />
                </div>

                {/* Password Field */}
                <div>
                  <label className="block text-white/90 mb-2 text-sm font-medium">
                    <div className="flex items-center">
                      <FaLock className="mr-2" />
                      Password
                    </div>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full px-4 py-3 pr-12 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white transition-colors"
                    >
                      {showPassword ? <FaEyeSlash /> : <FaEye />}
                    </button>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="flex justify-end items-center">
                  <button
                    type="button"
                    className="text-sm text-blue-300 hover:text-blue-200 transition-colors"
                  >
                    Forgot Password?
                  </button>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold rounded-lg shadow-lg transition-all duration-300 transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:transform-none flex items-center justify-center"
                >
                  {loading ? (
                    <div className="flex items-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      {isRegisterMode ? 'Registering...' : 'Signing In...'}
                    </div>
                  ) : (
                    <>
                      {isRegisterMode ? (
                        <>
                          <FaUserPlus className="mr-2" />
                          Register Now
                        </>
                      ) : (
                        <>
                          <FaSignInAlt className="mr-2" />
                          Sign In to Dashboard
                        </>
                      )}
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Security Note */}
            <div className="mt-6 text-center">
              <div className="inline-flex items-center text-white/50 text-sm">
                <FaShieldAlt className="mr-2" />
                Secure SSL Connection • Encrypted
              </div>
            </div>

            {/* Toggle between Login and Register */}
            <div className="mt-6 text-center">
              <p className="text-white/70 text-sm">
                {isRegisterMode ? (
                  <>
                    Already have an account?{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setIsRegisterMode(false);
                        setError('');
                        setSuccessMessage('');
                        setEmail('');
                        setPassword('');
                      }}
                      className="text-blue-300 hover:text-blue-200 font-semibold transition-colors underline"
                    >
                      Login here
                    </button>
                  </>
                ) : (
                  <>
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => {
                        setIsRegisterMode(true);
                        setError('');
                        setSuccessMessage('');
                        setEmail('');
                        setPassword('');
                      }}
                      className="text-blue-300 hover:text-blue-200 font-semibold transition-colors underline"
                    >
                      Register Now
                    </button>
                  </>
                )}
              </p>
            </div>
          </div>

          {/* Mobile Footer */}
          <div className="md:hidden mt-8 text-center text-white/60 text-sm">
            <p>© 2024 Shiv Pratap Multistate. All rights reserved.</p>
            <p className="mt-1">Version 2.5.1</p>
          </div>
        </div>
      </div>

      {/* Inline Styles */}
      <style jsx>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        @keyframes float {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
          100% { transform: translateY(0px); }
        }
        
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
        
        input::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }
        
        input:focus {
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
      `}</style>
    </div>
  );
};

export default Login;