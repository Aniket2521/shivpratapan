import React from 'react'

const Adminheading = () => {
  return (
    <div>
      
    </div>
  )
}

export default Adminheading
