import { 
  database, 
  ref as dbRef, 
  set 
} from './firebase';

// Initialize default marquee text
const initializeMarqueeText = async () => {
  try {
    const marqueeRef = dbRef(database, 'shivpratapmultistate/marquee');
    await set(marqueeRef, {
      text: '🚀 New Digital Savings Account with 7% interest!',
      updatedAt: new Date().toISOString(),
      updatedBy: 'system'
    });
    console.log('Marquee text initialized successfully!');
  } catch (error) {
    console.error('Error initializing marquee text:', error);
  }
};

// Run initialization
initializeMarqueeText();
